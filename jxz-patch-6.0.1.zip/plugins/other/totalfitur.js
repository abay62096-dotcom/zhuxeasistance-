const handler = async (m, { sock, getPluginStats }) => {
	const info = getPluginStats();
	
await sock.sendPollSnapshot(m.chat, {
  name: 'total fitur',  
  pollVotes: [
    { 
      optionName: 'plugins', 
      optionVoteCount: `${info.totalFiles}` 
    },
    { 
      optionName: 'category', 
      optionVoteCount: `${info.totalCategory}` 
    }
  ]
}, { quoted: m })
};
handler.command = ['totalfitur', 'fitur', 'ttf'];
export default handler;
