const handler = async (m, { sock, text }) => {
	let teks = `Special thank you 🤍

My God
Family
Jarr (Creator)
Nixel
Fgsi
Ahmad
Itsliaaa
Nebulous

And all of you, who have supported me!`

await sock.sendA2UI(m.chat, {
  text: teks,
  image: thumbnail,
  singleScreen: false, //atau true
  footer: '© jarrxz',
  buttons: [
    { 
      displayText: 'follow', 
      url: 'https://whatsapp.com/channel/0029VbBoflt4dTnNWXV4zC09' 
    }
  ]
}, { quoted: m })
}

handler.command = ['tqto', 'tq']
export default handler