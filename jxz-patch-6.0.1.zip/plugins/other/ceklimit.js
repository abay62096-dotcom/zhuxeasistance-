const formatDuration = (ms) => {
	const total = Math.ceil(ms / 1000);
	const h = Math.floor(total / 3600);
	const mnt = Math.floor((total % 3600) / 60);
	const d = total % 60;
	if (h > 0) return `${h} jam ${mnt} menit`;
	if (mnt > 0) return `${mnt} menit ${d} detik`;
	return `${d} detik`;
};

const handler = async (m, { db, isOwner, isPremium, reply }) => {
	if (isOwner || isPremium) {
		return reply(`*Limit check*

- status : ${isOwner ? 'owner' : 'premium'}
- limit : unlimited`);
	}

	const info = db.getLimitInfo(m.sender);
	reply(
		`*Limit check*

- status : free user
- limit : *${info.limit}/${info.max}*
- reset dalam : ${formatDuration(info.resetIn)}`
	);
};

handler.command = ['ceklimit', 'limit', 'mylimit'];
export default handler;
