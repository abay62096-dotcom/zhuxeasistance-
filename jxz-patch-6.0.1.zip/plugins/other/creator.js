const handler = async (m, { sock, reply }) => {
  try {
    const owners = [
      ['6285700158613', 'Alfi Anjar T', 'The creator']
    ]

    const contacts = owners.map(([number, name, about]) => ({
      displayName: name,
      vcard: `BEGIN:VCARD
VERSION:3.0
N:${name}
FN:${name}
ORG:${about}
TEL;type=CELL;type=VOICE;waid=${number}:${number}
END:VCARD`
    }))

    await sock.sendMessage(
      m.chat,
      {
        contacts: {
          displayName: `${owners.length} Owner`,
          contacts
        }
      },
      { quoted: m }
    )

    await reply(`Hii *${m.pushName}*, this is my owner!`)
  } catch (e) {
    console.error(e)
    await reply("❌ Terjadi error saat mengirim kontak owner!")
  }
}

handler.command = ["owner", "own"]
export default handler