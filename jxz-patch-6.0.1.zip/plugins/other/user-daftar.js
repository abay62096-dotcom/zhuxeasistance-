const handler = async (m, { sock, db, text, reply, example, botSet, usedPrefix }) => {
	if (!botSet.regis) return reply('Sistem pendaftaran sedang nonaktif, kamu bisa langsung pakai bot tanpa daftar.');

	if (db.isRegistered(m.sender)) {
		const u = await db.getUser(m.sender);
		return reply(`Kamu sudah terdaftar sebagai *${u.reg_name || u.name}*`);
	}

	const name = (text || '').trim().replace(/\s+/g, ' ');
	if (!name) return reply(example('nama'));
	if (name.length < 3 || name.length > 20) return reply('Nama harus 3 - 20 karakter!');
	if (!/^[\p{L}\p{N} ._-]+$/u.test(name)) return reply('Nama hanya boleh huruf, angka, spasi, titik, underscore, dan strip!');

	db.registerUser(m.sender, name);

    await sock.sendMessage(m.chat, {
      type: 'booking_confirmation',
      title: m.pushName,
      text: `*Register Succes*
	
- nama : ${name}
- id : ${m.sender.split('@')[0]}
- status : berhasil 

Kamu telah terdaftar, *${usedPrefix}menu* untuk memulai!`,
      footer: '© jarrxz',
      start_datetime: '2026-05-27T13:35:41.081Z',
      end_datetime: '2026-05-27T13:45:41.081Z',
      booking_url: 'https://whatsapp.com/channel/0029VbBoflt4dTnNWXV4zC09',
      phone_number: `${m.sender.split('@')[0]}`,
      booking_management_url: 'https://t.me/jarroffc2',
      description: 'Kamu telah terdaftar di database bot',
      display_text: 'view',
      display_content: {
        display_language: 'id',
        display_meeting_type: 'Register succes!'
      }
    }, { quoted: m })
};

handler.command = ['daftar', 'register', 'reg'];
handler.noregis = true;

export default handler;
