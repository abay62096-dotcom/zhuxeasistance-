const handler = async (m, { sock }) => {
	await sock.sendMessage(m.chat, {
		rich: {
			title: 'Bot Runtime',
			tip: `Bot sudah aktif selama:\n${global.runtime(process.uptime())}`
		}
	}, { quoted: m });
};

handler.command = ['rt', 'runtime'];
export default handler;