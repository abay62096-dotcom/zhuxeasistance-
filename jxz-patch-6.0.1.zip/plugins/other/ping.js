import os from 'os';
import { execSync } from 'child_process';

const formatSize = (bytes) => {
	if (!bytes) return '0 B';
	const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
	const i = Math.floor(Math.log(bytes) / Math.log(1024));
	return (bytes / Math.pow(1024, i)).toFixed(2) + ' ' + sizes[i];
};

const formatTime = (seconds) => {
	seconds = Number(seconds);
	const d = Math.floor(seconds / (3600 * 24));
	const h = Math.floor((seconds % (3600 * 24)) / 3600);
	const m = Math.floor((seconds % 3600) / 60);
	const s = Math.floor(seconds % 60);
	if (d > 0) return `${d}d ${h}h ${m}m`;
	if (h > 0) return `${h}h ${m}m ${s}s`;
	return `${m}m ${s}s`;
};

function bar(percent, len = 10) {
	const filled = Math.round((percent / 100) * len);
	return '█'.repeat(filled) + '░'.repeat(len - filled);
}

function getDisk() {
	try {
		const df = execSync('df -k --output=size,used / 2>/dev/null').toString();
		const lines = df.trim().split('\n');
		if (lines.length > 1) {
			const [total, used] = lines[1].trim().split(/\s+/).map(Number);
			return { total: total * 1024, used: used * 1024 };
		}
	} catch {}
	return { total: 0, used: 0 };
}

function getNetwork() {
	let totalRx = 0,
		totalTx = 0;
	try {
		const net = execSync('cat /proc/net/dev 2>/dev/null').toString();
		for (const line of net.split('\n')) {
			if (line.includes(':') && !line.includes('lo:')) {
				const parts = line.trim().split(/\s+/);
				totalRx += parseInt(parts[1]) || 0;
				totalTx += parseInt(parts[9]) || 0;
			}
		}
	} catch {}
	return { totalRx, totalTx };
}

function getOsName(platform, release) {
	if (platform === 'linux') {
		try {
			const id = execSync('grep ^PRETTY_NAME /etc/os-release 2>/dev/null').toString().split('=')[1]?.replace(/"/g, '').trim();
			if (id) return id;
		} catch {}
	}
	return `${platform} ${release}`;
}

function getCpuUsage() {
	try {
		const stat1 = execSync('cat /proc/stat 2>/dev/null').toString().split('\n')[0].trim().split(/\s+/).map(Number);
		execSync('sleep 0.2');
		const stat2 = execSync('cat /proc/stat 2>/dev/null').toString().split('\n')[0].trim().split(/\s+/).map(Number);
		const idle1 = stat1[4],
			total1 = stat1.slice(1).reduce((a, b) => a + b, 0);
		const idle2 = stat2[4],
			total2 = stat2.slice(1).reduce((a, b) => a + b, 0);
		const usage = (1 - (idle2 - idle1) / (total2 - total1)) * 100;
		return Math.min(100, Math.max(0, usage)).toFixed(1);
	} catch {
		const cpus = os.cpus();
		const load = os.loadavg()[0];
		return Math.min(100, (load * 100) / cpus.length).toFixed(1);
	}
}

function statusIcon(percent, warn = 70, crit = 85) {
	if (percent < warn) return '🟢';
	if (percent < crit) return '🟡';
	return '🔴';
}

const handler = async (m, { sock }) => {
	try {
		// Ukur latency via react (lebih ringan, 1 pesan aja)
		const start = Date.now();
		await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } });
		const latency = Date.now() - start;
		const cpus = os.cpus();
		const totalMem = os.totalmem();
		const freeMem = os.freemem();
		const ramUsed = totalMem - freeMem;
		const ramPercent = parseFloat(((ramUsed / totalMem) * 100).toFixed(1));
		const disk = getDisk();
		const net = getNetwork();
		const diskPercent = disk.total ? parseFloat(((disk.used / disk.total) * 100).toFixed(1)) : 0;
		const cpuPercent = parseFloat(getCpuUsage());
		const platform = os.platform();
		const osName = getOsName(platform, os.release());

		const pingIcon = latency < 150 ? '🟢' : latency < 400 ? '🟡' : '🔴';

		const text = `\`\`\`🖥️ SYSTEM MONITOR\`\`\`
    
📡 *PERFORMANCE*
- CPU : ${statusIcon(cpuPercent)} ${cpuPercent}% [${bar(cpuPercent)}]
- RAM : ${statusIcon(ramPercent)} ${ramPercent}% [${bar(ramPercent)}]
- ${formatSize(ramUsed)} / ${formatSize(totalMem)}
- Disk : ${statusIcon(diskPercent)} ${diskPercent}% [${bar(diskPercent)}]
-  ${formatSize(disk.used)} / ${formatSize(disk.total)}

💻 *HARDWARE*
- CPU : ${cpus[0].model.trim()}
- Cores : ${cpus.length} core${cpus.length > 1 ? 's' : ''}
- Speed : ${(cpus[0].speed / 1000).toFixed(2)} GHz
- Load : ${os
			.loadavg()
			.map((l) => l.toFixed(2))
			.join(' | ')} (1/5/15m)

🌐 *NETWORK*
- Total ↓ : ${formatSize(net.totalRx)}
- Total ↑ : ${formatSize(net.totalTx)} 

🔧 *SYSTEM INFO*
- Host : ${os.hostname()}
- OS : ${osName}
- Archl : ${os.arch()}
- Kernel : ${os.release()}
- Node.js : ${process.version}

🤖 *INFO BOT*
- Respons : ${pingIcon} ${latency} ms
- Runtime bot : ${formatTime(process.uptime())}
- Runtime VPS : ${formatTime(os.uptime())}
`.trim();

		await sock.sendMessage(m.chat, { text }, { quoted: m });
		await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } });
	} catch (e) {
		console.error(e);
		m.reply(`❌ Error: ${e.message}`);
	}
};

handler.command = ['ping', 'os', 'system'];
export default handler;
