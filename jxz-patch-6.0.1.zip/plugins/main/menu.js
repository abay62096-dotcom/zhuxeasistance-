/*

  WhatsApp bot base || Zhuxue-Asistance
  WhatsApp bot dengan library Baileys & runtime di NodeJs
  
  * Creator : Abay
  * Follow : https://whatsapp.com/channel/0029VbBoflt4dTnNWXV4zC09

 Jangan lupa baca README.md & EXAMPLE.js yaa

*/

import fs from 'fs'
import path from 'path'

const SETMENU_PATH = path.join(process.cwd(), 'plugins', 'main', 'setmenu.js')
let _cache = null
let _cacheMtime = 0

// ============================================================
// HELPER: FONT FORMAT
// ============================================================
const font = (text) => text || ''

// ============================================================
// LOAD SETMENU (FIX: Cek file ada dulu)
// ============================================================
const loadSetmenu = async () => {
	try {
		if (!fs.existsSync(SETMENU_PATH)) {
			console.error(`[MENU] File setmenu.js tidak ditemukan: ${SETMENU_PATH}`)
			return { MENU_TYPES: {} }
		}

		const stat = fs.statSync(SETMENU_PATH)
		if (_cache && stat.mtimeMs === _cacheMtime) return _cache

		const mod = await import(`file://${SETMENU_PATH}?update=${stat.mtimeMs}`)
		_cache = mod
		_cacheMtime = stat.mtimeMs
		return mod
	} catch (err) {
		console.error(`[MENU] Gagal load setmenu.js:`, err.message)
		return { MENU_TYPES: {} }
	}
}

// ============================================================
// HANDLER
// ============================================================
const handler = async (m, { sock, getMenuData, usedPrefix, isOwner, isPremium, text, botSet, getMenuConfig, isJadiBot, db }) => {

	// ============================================================
	// LOAD SETMENU
	// ============================================================
	const { MENU_TYPES } = await loadSetmenu()

	if (!MENU_TYPES || Object.keys(MENU_TYPES).length === 0) {
		return m.reply('*Error:* Menu types tidak tersedia. Cek file `setmenu.js`!')
	}

	// ============================================================
	// AMBIL DATA MENU
	// ============================================================
	const menu = getMenuData({ jadibot: isJadiBot })
	const sub = (text || '').trim().toLowerCase()

	// ============================================================
	// STATUS USER
	// ============================================================
	const status = isOwner ? '👑 Owner' : isPremium ? '💎 Premium' : '👤 Free User'
	const typeSub = font(`Ini hasil untuk *menu ${sub}*`)
	const prfx = botSet.multiprefix ? `[${botSet.prefix || '.'}]` : 'multi prefix'

	// ============================================================
	// INFO USER
	// ============================================================
	const info = m.senderInfo
	const myinfo = info?.username
		? `@${info.username}`
		: info?.jid?.split('@')[0]
		|| info?.lid?.split('@')[0]
		|| m.sender?.split('@')[0]
		|| 'Unknown'

	const limitInfo = (isOwner || isPremium)
		? '∞ Unlimited'
		: (() => {
			try {
				const l = db.getLimitInfo(m.sender)
				return `${l.limit}/${l.max}`
			} catch {
				return 'N/A'
			}
		})()

	// ============================================================
	// MENU CONFIG
	// ============================================================
	const config = getMenuConfig()
	const wantKey = isJadiBot && config.type === 'poll menu' ? 'extended' : config.type
	const entry = Object.values(MENU_TYPES).find(v => v.key === wantKey) || MENU_TYPES[2] || Object.values(MENU_TYPES)[0]

	if (!entry) {
		return m.reply('*Error:* Menu type tidak valid!')
	}

	// ============================================================
	// GREETING
	// ============================================================
	const greeting = m.pushName || 'Kak'

	// ============================================================
	// FORMAT SECTION
	// ============================================================
	const formatSection = (category, cmds) => {
		if (!cmds?.length) return ''

		const label = (c) => {
			if (typeof c === 'string') return `${usedPrefix}${c}`
			const name = `${usedPrefix}${c.cmd ?? c}`
			return c.aliases?.length ? `${name} (${c.aliases.join(', ')})` : name
		}

		const lines = cmds.map((c) => `  ◦ ${label(c)}`)
		return font(`*⌯ ${category.toUpperCase()}*\n${lines.join('\n')}`)
	}

	// ============================================================
	// BOT INFO (PAKAI GLOBAL.* AJA)
	// ============================================================
	const botInfo = font(`*⌯ Bot Info:*`) + `
  ├ Name     : *${global.namaBot}*
  ├ Creator  : *${global.namaOwner}*
  ├ Prefix   : \`${prfx}\`
  ├ Mode     : *${botSet.public ? 'Public' : 'Self'}*
  ├ Library  : *${global.library}*
  ├ Version  : \`${global.versi}\`
  ├ Runtime  : *${global.rtBot}*
  ├ Type     : *${global.typeSc}*
  └ Database : *${global.data}*`

	// ============================================================
	// USER INFO
	// ============================================================
	const userInfo = font(`*⌯ User Info:*`) + `
  ├ Name     : *${m.pushName || 'Unknown'}*
  ├ Number   : *${myinfo}*
  ├ Status   : *${status}*
  └ Limit    : \`${limitInfo}\``

	// ============================================================
	// CATEGORY ALIAS
	// ============================================================
	const CATEGORY_ALIAS = {
		random: 'other',
	}

	const allFolders = Object.keys(menu).sort()
	let teks = ''

	// ============================================================
	// MENU: ALL
	// ============================================================
	if (sub === 'all') {
		teks = font(`👋 Hello *${greeting}*`) + '\n'
		teks += font(`Berikut adalah *semua command* di script ini!`) + '\n\n'
		teks += botInfo + '\n\n'
		teks += userInfo + '\n\n'

		for (const [cat, cmds] of Object.entries(menu)) {
			teks += formatSection(cat, cmds) + '\n\n'
		}

	// ============================================================
	// MENU: CATEGORY SPESIFIK
	// ============================================================
	} else if (sub) {
		const folder = CATEGORY_ALIAS[sub] || sub
		teks = `👋 Hello *${greeting}*\n${typeSub}\n\n${userInfo}\n\n`

		if (menu[folder]?.length) {
			teks += formatSection(folder, menu[folder]) + '\n'
		} else if (folder in menu) {
			teks += `⚠️ Belum ada command di kategori *${folder}*\n`
		} else {
			teks += `❌ *Kategori ${sub}* tidak ditemukan.\n\n`
			teks += `📁 *Kategori tersedia:*\n`
			teks += allFolders.map(f => `  ◦ ${f}`).join('\n') + '\n'
		}

	// ============================================================
	// MENU: UTAMA
	// ============================================================
	} else {
		const REVERSE_ALIAS = Object.fromEntries(
			Object.entries(CATEGORY_ALIAS).map(([k, v]) => [v, k])
		)
		const list = ['all', ...allFolders.map(f => REVERSE_ALIAS[f] || f)]

		teks = font(`👋 Hello *${greeting}*`) + '\n'
		teks += font(`Berikut adalah *kategori menu* yang tersedia!`) + '\n\n'
		teks += botInfo + '\n\n'
		teks += userInfo + '\n\n'
		teks += font(`*⌯ Category Menu:*`) + '\n'
		teks += list.map(c => `  ◦ ${c}`).join('\n') + '\n\n'
		teks += font(`*📖 Cara pakai:* ${usedPrefix}menu [category]`) + '\n'
		teks += font(`*📌 Contoh:* ${usedPrefix}menu all`)
	}

	// ============================================================
	// BUILD MENU
	// ============================================================
	if (entry.buildSubmenuPoll && sub) {
		return entry.buildSubmenuPoll({ sock, m, customText: teks })
	}

	return entry.build({
		sock,
		m,
		menu,
		usedPrefix,
		status,
		customText: teks,
		isMainMenu: !sub
	})
}

handler.command = ['menu']
export default handler