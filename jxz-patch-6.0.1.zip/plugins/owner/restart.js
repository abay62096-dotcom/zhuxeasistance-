import { spawn } from 'child_process';

const handler = async (m, { sock, reply }) => {
	const restartServer = () => {
		const newProcess = spawn(process.argv[0], process.argv.slice(1), {
			detached: true,
			stdio: 'inherit',
		});
		process.exit(0);
	};

	await reply(`\`\`\`Restarting bot . . .\`\`\``);
	setTimeout(() => restartServer(), 4500);
};

handler.command = ['rst', 'restart'];
handler.owner = true;
handler.noJadiBot = true
handler.mainOwner = true

export default handler;
