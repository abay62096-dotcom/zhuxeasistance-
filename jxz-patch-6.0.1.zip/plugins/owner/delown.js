import fs from 'fs';

const handler = async (m, { sock, text, args, reply, owners, example }) => {
	if (m.isBaileys) return m.reply('ngapain 😂?');

	let targetJid = null;
	if (args[0]) {
		const clean = args[0].replace(/[^0-9]/g, '');
		if (!clean) return reply(example(`reply/tag/nomor`));
		targetJid = clean + '@s.whatsapp.net';
	} else if (m.quoted?.sender) {
		targetJid = m.quoted.sender;
	} else if (m.mentionedJid?.[0]) {
		targetJid = m.mentionedJid[0];
	}
	if (!targetJid) return reply(example(`reply/tag/nomor`));

	const norm = (j) => j.split('@')[0].split(':')[0];
	let idx = owners.indexOf(targetJid);
	if (idx === -1) idx = owners.findIndex(o => norm(o) === norm(targetJid));

	if (idx === -1) return reply('Nomor tidak ditemukan di daftar owner.');
	const removed = owners[idx];
	owners.splice(idx, 1);
	fs.writeFileSync('./data/owner.json', JSON.stringify(owners));
	reply(`Berhasil menghapus ${removed.split('@')[0]} dari daftar owner.`);
};

handler.command = ['delown', 'delowner'];
handler.owner = true;
handler.noJadiBot = true
handler.mainOwner = true

export default handler;
