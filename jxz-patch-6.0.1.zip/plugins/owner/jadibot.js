import fs from 'fs'
import path from 'path'
import pino from 'pino'
import { Boom } from '@hapi/boom'
import NodeCache from 'node-cache';
import chalk from 'chalk';
import {
	makeWASocket,
	useMultiFileAuthState,
	fetchLatestBaileysVersion,
	DisconnectReason,
	makeCacheableSignalKeyStore,
	Browsers
} from '@whiskeysockets/baileys'

import ConfigBaileys from '../../lib/import.js'
import { createJadibotDatabase } from '../../data/database.js'
import { attachIdentityHelpers } from '../../lib/helper-cmd/jidDecode.js'

const jb = (globalThis.__jadibot ||= {
	bots: new Map(),
	jbDbs: new Map(),
	notify: new Map(),
	pairingInProgress: new Set(),
	pairingTimeouts: new Map(),
	resumed: false,
})
const { bots, jbDbs, notify, pairingInProgress, pairingTimeouts } = jb
const sessionsDir = path.join(process.cwd(), 'sessions_jadibot')

const getJbDb = (number) => {
	if (!jbDbs.has(number)) jbDbs.set(number, createJadibotDatabase(number))
	return jbDbs.get(number)
}
const destroyJbDb = (number) => {
	const d = jbDbs.get(number)
	if (d) { d.destroy(); jbDbs.delete(number) }
	notify.delete(number)
}

if (!fs.existsSync(sessionsDir)) {
	fs.mkdirSync(sessionsDir, { recursive: true })
}

const groupCache = new NodeCache({
	stdTTL: 5 * 60,
	useClones: false,
});

const normalizeNumber = (num = '') => num.replace(/[^0-9]/g, '')

const isRegisteredSession = (number) => {
	try {
		const creds = JSON.parse(fs.readFileSync(path.join(sessionsDir, number, 'creds.json'), 'utf-8'))
		return creds?.registered === true
	} catch {
		return false
	}
}

const resumeJadibots = async () => {
	let list = []
	try {
		list = fs.readdirSync(sessionsDir).filter((n) => /^\d+$/.test(n) && isRegisteredSession(n))
	} catch {}
	if (!list.length) return

	console.log(chalk.cyan(`[jadibot] auto-resume ${list.length} sesi...`))
	for (const num of list) {
		if (bots.has(num)) continue
		try {
			await startJadiBot(num, null, true)
		} catch (e) {
			console.log(chalk.red(`[jadibot] gagal resume ${num}:`), e?.message || e)
		}
		await new Promise((r) => setTimeout(r, 3000))
	}
}

if (!jb.resumed) {
	jb.resumed = true
	setTimeout(resumeJadibots, 5000)
}

async function startJadiBot(number, m, isStart = false) {
	const cleanNumber = normalizeNumber(number)
	const sessionName = `${cleanNumber}`
	const sessionPath = path.join(sessionsDir, sessionName)

	const { state, saveCreds } = await useMultiFileAuthState(sessionPath)
	const { version: v } = await fetchLatestBaileysVersion();

	const clients = makeWASocket({
		printQRInTerminal: false,
		logger: pino({ level: 'silent' }),
		version: v,
		browser: Browsers.macOS('Safari'),
        syncFullHistory: true,
        markOnlineOnConnect: true,

		cachedGroupMetadata: async (jid) => groupCache.get(jid),

		auth: {
			creds: state.creds,
			keys: makeCacheableSignalKeyStore(state.keys, pino({ level: 'silent' }))
		}
	})

	makeButtonsHelper(clients)
    makeA2UIHelper(clients);
    makeRichHelper(clients);
	clients.isJadiBot = true

	clients.db = getJbDb(cleanNumber)
	clients.botSet = clients.db.botSet

	clients.ev.on('creds.update', saveCreds)

	attachIdentityHelpers(clients, groupCache)

	clients.ev.on('connection.update', async (update) => {
		const { connection, lastDisconnect } = update

		if (connection === 'connecting') {
			console.log(chalk.yellow(`Connecting jadibot ${cleanNumber}`))
		}

		if (connection === 'open') {
			console.log(chalk.green(`Connected jadibot ${cleanNumber}`))

			const pending = pairingTimeouts.get(cleanNumber)
			if (pending) {
				clearTimeout(pending)
				pairingTimeouts.delete(cleanNumber)
			}

			bots.set(cleanNumber, {
				socket: clients,
				session: sessionPath
			})

			clients.insertAllGroup?.()

			const req = notify.get(cleanNumber)
			if (req) {
				notify.delete(cleanNumber)
				const bs = clients.botSet
				const info = `*Bot success connect ✅*

- Number: *${cleanNumber}*
- Status: *active*
- Mode: *${bs.public ? 'public' : 'self'}*
- Prefix: *${bs.multiprefix ? bs.prefix : 'multi prefix'}*

Ketik *${bs.multiprefix ? bs.prefix : '.'}menu* untuk melihat fitur

> © jarrxz`
				try { await global.mainSock.sendMessage(req.chat, { text: info }, { quoted: req }) } catch {}
				try { await clients.sendMessage(clients.decodeJid(clients.user.id), { text: info }) } catch {}
			}
		}

		if (connection === 'close') {
			const reason = new Boom(lastDisconnect?.error)?.output?.statusCode

			console.log(chalk.red(`Jadibot close ${cleanNumber}: ${reason}`))

			if (!state.creds.registered) {
				console.log(chalk.red(`Jadibot pairing gagal ${cleanNumber} (reason: ${reason})`))

				const pending = pairingTimeouts.get(cleanNumber)
				if (pending) {
					clearTimeout(pending)
					pairingTimeouts.delete(cleanNumber)
				}

				pairingInProgress.delete(cleanNumber)
				bots.delete(cleanNumber)
				destroyJbDb(cleanNumber)

				if (fs.existsSync(sessionPath)) {
					fs.rmSync(sessionPath, { recursive: true, force: true })
				}

				if (m?.chat) {
					try {
						await global.mainSock.sendMessage(m.chat, {
							text: `*Gagal menautkan perangkat!*\n\nKode pairing untuk *${cleanNumber}* tidak berhasil ditautkan (kadaluarsa/salah/dibatalkan).\n\nSilakan coba lagi: ${global.prefix || '.'}jadibot ${cleanNumber}`
						}, { quoted: m }).catch(() => {})
					} catch {}
				}

				return
			}

			if (reason === DisconnectReason.loggedOut) {
				console.log(chalk.red(`Jadibot logout ${cleanNumber}`))

				bots.delete(cleanNumber)
				destroyJbDb(cleanNumber)

				if (fs.existsSync(sessionPath)) {
					fs.rmSync(sessionPath, { recursive: true, force: true })
				}

				return
			}

			if (
				clients?.ws?.readyState === 1 ||
				clients?.ws?.readyState === 0
			) return

			console.log(chalk.yellow(`Reconnect jadibot ${cleanNumber}...`))

			setTimeout(async () => {
				try {
					await startJadiBot(cleanNumber, m, true)
				} catch (e) {
					console.log('Reconnect error:', e)
				}
			}, 5000)
		}
	})

	if (!state.creds.registered && !pairingInProgress.has(cleanNumber)) {
		pairingInProgress.add(cleanNumber)

		await new Promise(resolve => setTimeout(resolve, 2000))

		try {
			const code = await clients.requestPairingCode(cleanNumber)
			const format = code.match(/.{1,4}/g)?.join('-')

			await global.mainSock.sendButtons(m.chat, {
				text: `Your pairing code: *${format}*\n\nMasukan kode di WhatsApp:\n> Settings › perangkat tertaut › tautkan dengan nomor\n\n_Kode berlaku sekitar 60 detik, jika tidak segera dipasang akan otomatis dibatalkan._`,
				footer: `© powered by jarrxz`,
				buttons: [
					{ copy: format, text: 'Copy code' }
				]
			}, { quoted: m })

			const timeout = setTimeout(async () => {
				pairingTimeouts.delete(cleanNumber)
				if (state.creds.registered || bots.has(cleanNumber)) return

				console.log(chalk.red(`Jadibot pairing timeout ${cleanNumber}`))

				pairingInProgress.delete(cleanNumber)

				try { await clients.logout() } catch {}
				try { clients.end?.(new Error('pairing timeout')) } catch {}

				bots.delete(cleanNumber)
				destroyJbDb(cleanNumber)

				if (fs.existsSync(sessionPath)) {
					fs.rmSync(sessionPath, { recursive: true, force: true })
				}

				if (m?.chat) {
					try {
						await global.mainSock.sendMessage(m.chat, {
							text: `*Gagal menautkan perangkat!*\n\nKode pairing untuk *${cleanNumber}* kadaluarsa (tidak dipasang dalam waktu 90 detik).\n\nSilakan coba lagi: ${global.prefix || '.'}jadibot ${cleanNumber}`
						}, { quoted: m }).catch(() => {})
					} catch {}
				}
			}, 90_000)

			pairingTimeouts.set(cleanNumber, timeout)

		} catch (e) {
			console.log('Pairing Error:', e)

			try { await clients.logout() } catch {}

			bots.delete(cleanNumber)
			destroyJbDb(cleanNumber)

			if (fs.existsSync(sessionPath)) {
				fs.rmSync(sessionPath, { recursive: true, force: true })
			}

			try {
				await m.reply(`*Gagal generate pairing code:*\n\n${e.message}`)
			} catch {}

		} finally {
			pairingInProgress.delete(cleanNumber)
		}
	}

	clients.ev.on('groups.update', async ([event]) => {
		try {
			groupCache.set(event.id, await clients.groupMetadata(event.id))
		} catch {}
	})

	clients.ev.on('group-participants.update', async (event) => {
		try {
			groupCache.set(event.id, await clients.groupMetadata(event.id))
			await global.handleGroupUpdate(event, clients)
		} catch {}
	})

	clients.ev.on('messages.upsert', async (chatUpdate) => {
		try {
			if (chatUpdate.type !== 'notify') return
			const msg = chatUpdate.messages?.[0]
			if (!msg.message) return;
			if (msg.key.fromMe && !global.bot) return;
			const m2 = await ConfigBaileys(clients, msg)
			m2.isJadiBot = true
			await handler_cmd(clients, m2, chatUpdate)
		} catch (e) {
			console.log('Jadibot message error:', e)
		}
	})

	return clients
}

const handler = async (m, { command, args, usedPrefix }) => {

	switch (command) {

		case "jadibot": {
			const number = normalizeNumber(args[0] || '')

			if (!number) return m.reply(`Masukkan nomor terdaftar di WhatsApp!\n\nExample: ${usedPrefix}jadibot 628xxxx`)
			if (bots.has(number)) return m.reply('Bot sudah aktif')
			if (isRegisteredSession(number)) return m.reply('Sesi nomor ini sudah ada & sedang menyambung ulang, tunggu sebentar lalu cek ' + usedPrefix + 'listjadibot')

			await m.reply('Load pairing code. . .')
			notify.set(number, m)
			await startJadiBot(number, m)
		}
		break

		case "listjadibot":
		case "listbot": {
			if (bots.size === 0) return m.reply('Tidak ada jadibot aktif')

			let text = '*List jadibot:*\n\n'
			for (const [num] of bots) {
				text += `- ${num}\n`
			}

			return m.reply(text)
		}
		break

		case "stopjadibot":
		case "stopbot": {
			const number = normalizeNumber(args[0] || '')

			if (!number) return m.reply(`Example: ${usedPrefix}stopjadibot 62xxx\n\n${usedPrefix}listjadibot untuk melihat nomor`)

			const bot = bots.get(number)
			if (!bot) return m.reply('Nomor tidak ditemukan sebagai jadibot')

			bots.delete(number)

			try {
				await bot.socket.logout()
			} catch {}
			destroyJbDb(number)

			if (bot.session && fs.existsSync(bot.session)) {
				fs.rmSync(bot.session, { recursive: true, force: true })
			}

			m.reply('*Jadibot* berhasil dimatikan!')
		}
		break
	}
}

handler.command = [
	'jadibot',
	'listjadibot',
	'listbot',
	'stopbot',
	'stopjadibot',
]

handler.premium = true
handler.noJadiBot = true
handler.mainOwner = true

export default handler