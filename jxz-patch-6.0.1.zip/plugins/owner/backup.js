import fs from 'fs';
import path from 'path';
import { execSync } from 'child_process';

const handler = async (m, { sock, reply, botNumber }) => {
	const d = new Date();
	const date = d.toLocaleDateString('id-ID', { day: 'numeric', month: 'long', year: 'numeric' });

	function jam(tz = 'Asia/Jakarta') {
		return new Date().toLocaleTimeString('id-ID', {
			timeZone: tz,
			hour: '2-digit',
			minute: '2-digit',
			second: '2-digit',
		});
	}

	const senderNum = m.sender.split('@')[0];
	const botNum = botNumber ? botNumber.split('@')[0] : sock.user.id.split(':')[0];

	const isCreator = global.owner.includes(senderNum) || m.key.fromMe || senderNum === botNum;

	try {
		await reply('*Processing Backup Script...*');
		const tmpDir = './data/trash';
		if (fs.existsSync(tmpDir)) {
		}

		const cleanDate = date.replace(/\s/g, '-');
		const name = `backup-${Date.now()}`;

		const exclude = ['node_modules', 'session', 'Auth', 'package-lock.json', 'yarn.lock', '.npm', '.cache', '.git'];

		const filesToZip = fs
			.readdirSync(process.cwd())
			.filter((f) => !exclude.includes(f) && f !== '')
			.map((f) => `"${f}"`)
			.join(' ');

		if (!filesToZip.length) return reply('Tidak ada file yang dapat di-backup.');

		execSync(`zip -r ${name}.zip ${filesToZip}`);

		const stats = fs.statSync(`./${name}.zip`);
		const fileSizeInMB = (stats.size / (1024 * 1024)).toFixed(2);

		await sock.sendMessage(
			m.sender,
			{
				document: fs.readFileSync(`./${name}.zip`),
				fileName: `${name}.zip`,
				caption: `*Succes backup script*
        
- 📅 Tanggal: ${date}
- ⏰ Waktu: ${jam('Asia/Jakarta')} WIB 
- 📦 Ukuran: ${fileSizeInMB} MB`,
				mimetype: 'application/zip',
			},
			{ quoted: m }
		);

		fs.unlinkSync(`./${name}.zip`);

		if (m.isGroup) reply('Script bot berhasil dikirim ke private chat.');
	} catch (err) {
		console.error('Backup Error:', err);

		if (err.message.includes('zip: not found') || err.message.includes("'zip' is not recognized")) {
			reply("❌ Gagal: Command 'zip' tidak ditemukan. Pastikan VPS/Panel sudah terinstall zip.\n(Linux: `apt install zip`)");
		} else {
			reply('❌ Terjadi kesalahan saat melakukan backup.');
		}
	}
};

handler.command = ['backup', 'bck', 'backupsc'];
handler.owner = true;
handler.noJadiBot = true
handler.mainOwner = true

export default handler;
