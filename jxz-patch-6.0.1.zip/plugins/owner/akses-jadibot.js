import fs from 'fs'
import path from 'path'

const DB_PATH = path.join(process.cwd(), 'data', 'clonebot.json')

const normNum = (v) => String(v || '').split('@')[0].split(':')[0].replace(/[^0-9]/g, '')

const loadDb = () => {
	try {
		if (!fs.existsSync(DB_PATH)) {
			fs.writeFileSync(DB_PATH, '[]')
			return []
		}
		const raw = fs.readFileSync(DB_PATH, 'utf-8')
		const arr = JSON.parse(raw)
		return Array.isArray(arr) ? arr : []
	} catch {
		return []
	}
}

const saveDb = (arr) => {
	fs.writeFileSync(DB_PATH, JSON.stringify(arr, null, 2))
}

global.isCloneBot = (jidOrNumber) => {
	const num = normNum(jidOrNumber)
	if (!num) return false
	const db = loadDb()
	return db.includes(num)
}

global.addCloneBot = (jidOrNumber) => {
	const num = normNum(jidOrNumber)
	if (!num) return false
	const db = loadDb()
	if (db.includes(num)) return false
	db.push(num)
	saveDb(db)
	return true
}

global.delCloneBot = (jidOrNumber) => {
	const num = normNum(jidOrNumber)
	if (!num) return false
	const db = loadDb()
	const idx = db.indexOf(num)
	if (idx === -1) return false
	db.splice(idx, 1)
	saveDb(db)
	return true
}

const resolveTargetNumber = (m, args) => {
	if (args[0]) return normNum(args[0])
	if (m.quoted?.sender) return normNum(m.quoted.sender)
	if (m.mentionedJid?.[0]) return normNum(m.mentionedJid[0])
	return null
}

const handler = async (m, { reply, args, example, usedPrefix }) => {
	const sub = (args[0] || '').toLowerCase()

	if (sub === 'list') {
		const db = loadDb()
		if (db.length < 1) return reply('Belum ada nomor jadibot yang diwhitelist (clonebot).')
		let teks = `*List akses jadibot*\n\n`
		for (const num of db) teks += `- ${num}\n`
		return reply(teks)
	}

	if (sub === 'add') {
		const number = resolveTargetNumber(m, args.slice(1))
		if (!number) return reply(`kirim nomor targetnya.\n\nContoh: ${usedPrefix}clonebot + 628xxx`)
		const ok = global.addCloneBot(number)
		if (!ok) return reply(`Nomor *${number}* sudah ada di whitelist clonebot.`)
		return reply(`Berhasil menambahkan *${number}* ke whitelist clonebot.\n\nJadibot dengan nomor ini sekarang tetap bisa memakai fitur khusus owner (noJadiBot).`)
	}

	if (sub === 'del' || sub === 'remove') {
		const number = resolveTargetNumber(m, args.slice(1))
		if (!number) return reply(`Kirim nomor targetnya.\n\nContoh: ${usedPrefix}clonebot - 628xxx`)
		const ok = global.delCloneBot(number)
		if (!ok) return reply(`Nomor *${number}* tidak ditemukan di whitelist clonebot.`)
		return reply(`Berhasil menghapus akses *${number}* dari whitelist clonebot.`)
	}

	return reply(
		`Format salah!\n\n` +
		`${usedPrefix}clonebot add 628xxx (atau reply/tag nomornya)\n` +
		`${usedPrefix}clonebot del 628xxx (atau reply/tag nomornya)\n` +
		`${usedPrefix}clonebot list`
	)
}

handler.command = ['clonebot', 'aksesjadibot']
handler.owner = true
handler.noJadiBot = true

export default handler