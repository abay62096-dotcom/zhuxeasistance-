import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const handler = async (m, { sock, text, command, reply, usedPrefix }) => {
	try {
		let fileName, fileContent;
		if (m.quoted && m.quoted.text) {
			fileName = text.trim();
			fileContent = m.quoted.text;
		} else {
			if (!text) return reply(`Reply code pluginsnya *${usedPrefix + command} folder_category/nama_file.js*`);

			const splitIndex = text.indexOf(' ');
			if (splitIndex === -1) return reply(`Reply code pluginsnya *${usedPrefix + command} folder_category/nama_file.js*`);

			fileName = text.substring(0, splitIndex).trim();
			fileContent = text.substring(splitIndex + 1).trim();
		}

		if (!fileName.endsWith('.js')) {
			return reply(`Gagal! Nama file harus berakhiran *.js*\nContoh: *command/menu.js*`);
		}

		const hasExport = /export\s+default\s+handler/.test(fileContent);

		const hasCommand = /handler\.command\s*=\s*\[/.test(fileContent);

		const hasAsync = /const\s+handler\s*=\s*async/.test(fileContent) || /let\s+handler\s*=\s*async/.test(fileContent);

		if (!hasExport || !hasCommand || !hasAsync) {
			return reply(`*Format plugin tidak valid!*
        
*Contoh kode plugin benar:*
const handler = async (m, { sock }) => {
   m.reply("contoh!!")
}
handler.command = ["tes"]
export default handler;`);
		}

		const baseDir = path.join(__dirname, '../../plugins');
		const filePath = path.join(baseDir, fileName);
		const dirPath = path.dirname(filePath);

		if (!fs.existsSync(dirPath)) {
			fs.mkdirSync(dirPath, { recursive: true });
		}

		fs.writeFileSync(filePath, fileContent);

		return reply(`Berhasil menyimpan plugins *./plugins/${fileName}*`);
	} catch (err) {
		console.error(err);
		reply('Terjadi kesalahan: ' + err.message);
	}
};

handler.command = ['addp', 'addplugin', 'sp', 'svp'];
handler.owner = true;
handler.noJadiBot = true
handler.mainOwner = true

export default handler;
