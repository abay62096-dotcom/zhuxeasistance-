import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const handler = async (m, { sock, text, command, reply, usedPrefix }) => {
	try {
		const baseDir = path.join(__dirname, '../../plugins');

		if (!text || !text.endsWith('.js')) return reply(`Contoh: *${usedPrefix + command}* command/menu.js\n\nKetik: *${usedPrefix}listplugin* untuk lihat file plugins`);

		const targetPath = path.join(baseDir, text.trim());

		if (!fs.existsSync(targetPath)) return reply(`Plugin tidak ditemukan di:\n${targetPath}`);

		const fileContent = fs.readFileSync(targetPath, 'utf8');

		return await sock.sendButtons(
			m.chat,
			{
				text: `${fileContent}`,
				footer: `GET | ${text.trim()}`,
				buttons: [
					{
						name: 'cta_copy',
						buttonParamsJson: JSON.stringify({
							display_text: 'copy code',
							copy_code: fileContent,
							id: 'copy_plugin_code',
						}),
					},
				],
			},
			{ quoted: m }
		);
	} catch (err) {
		console.error(err);
		return reply('Terjadi kesalahan saat membaca plugin.');
	}
};

handler.command = ['getp', 'gp', 'getplugin', 'getplugins'];
handler.owner = true;
handler.noJadiBot = true
handler.mainOwner = true

export default handler;
