import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const handler = async (m, { sock, reply, usedPrefix }) => {
	try {
		const baseDir = path.join(__dirname, '../../plugins');
		if (!fs.existsSync(baseDir)) return reply('Folder ./plugins tidak ditemukan.');

		// ambil semua kategori (folder)
		const categories = fs.readdirSync(baseDir).filter((f) => {
			const fullPath = path.join(baseDir, f);
			return fs.statSync(fullPath).isDirectory();
		});

		let totalFiles = 0;
		let teks = '';

		for (const category of categories) {
			const catPath = path.join(baseDir, category);
			const files = fs.readdirSync(catPath).filter((f) => f.endsWith('.js'));
			totalFiles += files.length;

			teks += `\n\`${category.charAt(0).toUpperCase() + category.slice(1)}\`\n`;
			for (const file of files) {
				teks += `> ./plugins/${category}/${file}\n`;
			}
		}

		const header = `*Info plugin files*
- *File plugin:* ${totalFiles}
- *Total folder:* ${categories.length}

*Command vailid*
- ${usedPrefix}getplugin folder_categornya/filenya.js
- ${usedPrefix}addplugin folder_categornya/filenya.js (reply codenya)
- ${usedPrefix}delplugin folder_categornya/filenya.js\n`;
		return reply(header + teks);
	} catch (err) {
		console.error(err);
		reply('Terjadi kesalahan saat membaca daftar plugin.');
	}
};

handler.command = ['listplugin', 'listp', 'listplugins', 'lp'];
handler.owner = true;
handler.noJadiBot = true
handler.mainOwner = true

export default handler;
