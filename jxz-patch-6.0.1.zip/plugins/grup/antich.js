
const handler = async (m, { args, command, usedPrefix, updateData }) => {
  const sub = args[0]?.toLowerCase()

  if (sub === 'on') {
    await updateData('groups', m.chat, 'antilinkch', 1)
    return m.reply('Fitur *Anti Link Channel* berhasil diaktifkan!')
  }

  if (sub === 'off') {
    await updateData('groups', m.chat, 'antilinkch', 0)
    return m.reply('Fitur *Anti Link Channel* dimatikan.')
  }

  return m.reply(`*Anti Link Channel*\n\n› ${usedPrefix + command} on\n› ${usedPrefix + command} off`)
}

handler.before = async (m, { sock, isOwner, isAdmin, isBotAdmin, getGroup }) => {
  if (!m.isGroup) return
  if (isOwner || isAdmin) return
  if (!isBotAdmin) return

  const chatDb = await getGroup(m.chat)
  if (chatDb?.antilinkch !== 1) return

  const isLinkChannel = (
    m.msg?.contextInfo?.isForwarded &&
    m.msg?.contextInfo?.forwardingScore >= 1 &&
    m.msg?.contextInfo?.forwardedNewsletterMessageInfo?.newsletterJid
  )

  const hasChannelLink = m.text && /https?:\/\/whatsapp\.com\/channel\/[A-Za-z0-9]+/i.test(m.text)

  if (!isLinkChannel && !hasChannelLink) return

  await sock.sendMessage(m.chat, {
    text: `@${m.sender.split('@')[0]} dilarang kirim link/forward channel!`,
    mentions: [m.sender]
  })

  await sock.sendMessage(m.chat, {
    delete: {
      remoteJid: m.chat,
      id: m.key.id,
      participant: m.key.participant || m.sender,
      fromMe: false
    }
  })
}

handler.command = ['antilinkch', 'antich']
handler.group = true
handler.admin = true
handler.botadmin = true

export default handler