import moment from 'moment-timezone'

const handler = async (m, { text, reply, updateData, usedPrefix }) => {
	if (!text) return reply(`Contoh pengguna:\n\n${usedPrefix}welcome on\n${usedPrefix}welcome off`)

	const sub = text.toLowerCase()

	if (sub === 'on') {
		await updateData('groups', m.chat, 'welcome', 1)
		await updateData('groups', m.chat, 'goodbye', 1)
		return reply('Welcome aktif ✅')
	}

	if (sub === 'off') {
		await updateData('groups', m.chat, 'welcome', 0)
		await updateData('groups', m.chat, 'goodbye', 0)
		return reply('Welcome dimatikan ❌')
	}

	reply('Gunakan on / off')
}

handler.onGroupUpdate = async (update, { sock, getGroup }) => {
	const { id, author, participants, action } = update
	if (!id || !participants) return

	const groupData = await getGroup(id)
	if (!groupData) return

	const now = moment().tz('Asia/Jakarta')
	const date = `${now.format('DD MMMM YYYY')} | ${now.format('HH:mm:ss')} WIB`
	const url = 'https://whatsapp.com/channel/0029VbBoflt4dTnNWXV4zC09'

	let groupName = 'Group WhatsApp', totalMembers = 0, totalAdmins = 0

	try {
		const metadata = await sock.groupMetadata(id)
		groupName = metadata.subject
		totalMembers = metadata.participants.length
		totalAdmins = metadata.participants.filter(v => v.admin !== null).length
	} catch {
		console.log('Gagal ambil metadata grup')
	}

	const sendPreview = (text, mentions, thumb) => sock.sendLinkPreview(id, {
		text: `${url}\n\n${text}`,
		url,
		title: date,
		description: "",
		...(thumb ? { thumbnail: thumb, thumbnailWidth: 640, thumbnailHeight: 640 } : {}),
		contextInfo: { mentionedJid: mentions.filter(Boolean) }
	})

	for (const n of participants) {
		const user = typeof n === 'string' ? n : n?.id || n?.jid || ''
		if (!user) continue

		const tag = user.split('@')[0]
		const actor = author ? author.split('@')[0] : 'Admin'
		const pp = await sock.profilePictureUrl(user, 'image').catch(() => null)

		if (action === 'add' && groupData.welcome === 1) {
			await sendPreview(
				`*Welcome!*\n\nHallo @${tag}, selamat datang di grup *${groupName}* 👋\n\n> Total member: ${totalMembers}`,
				[user], pp
			)
		} else if (action === 'remove' && groupData.goodbye === 1) {
			await sendPreview(
				`*Goodbye!*\n\nSelamat tinggal @${tag} 👋\n\n> Sisa member: ${totalMembers}`,
				[user], pp
			)
		} else if (action === 'promote' && groupData.welcome === 1) {
			await sendPreview(
				`*Promoted!*\n\nKini @${tag} sekarang menjadi admin grup\nPromoted by @${actor}\n\n> Total admin: ${totalAdmins}`,
				[user, author], pp
			)
		} else if (action === 'demote' && groupData.welcome === 1) {
			await sendPreview(
				`*Demoted!*\n\nKini @${tag} bukan admin lagi\nDemoted by @${actor}\n\n> Sisa admin: ${totalAdmins}`,
				[user, author], pp
			)
		}
	}
}

handler.command = ['welcome']
handler.admin = true
handler.group = true

export default handler