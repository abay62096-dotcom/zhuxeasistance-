const handler = async (m, { args, command, usedPrefix, updateData }) => {
	const text = args[0] ? args[0].toLowerCase() : '';

	if (text === 'on') {
		await updateData('groups', m.chat, 'antilink', 1);
		return m.reply(`Fitur *Antilink* berhasil diaktifkan!`);
	}

	if (text === 'off') {
		await updateData('groups', m.chat, 'antilink', 0);
		return m.reply(`Fitur *Antilink* dimatikan.`);
	}

	return m.reply(`*Mode Switch Antilink*\n\nCara pakai:\n› ${usedPrefix + command} on\n› ${usedPrefix + command} off`);
};

handler.before = async (m, { sock, isOwner, isAdmin, isBotAdmin, getGroup }) => {
	if (!m.isGroup || !m.text) return;
	const chatDb = await getGroup(m.chat);
	if (chatDb?.antilink !== 1) return;
	if (isOwner || isAdmin) return;
	if (!isBotAdmin) return;

	const regex = /chat\.whatsapp\.com\/[A-Za-z0-9]{20,24}/i;
	if (!regex.test(m.text)) return;

	await sock.sendMessage(m.chat, {
		text: `@${m.sender.split('@')[0]} jangan kirim link grup!`,
		mentions: [m.sender]
	}, { quoted: null });

	await sock.sendMessage(m.chat, {
		delete: {
			remoteJid: m.chat,
			id: m.key.id,
			participant: m.key.participant || m.sender,
			fromMe: false
		}
	});
};

handler.command = ['antilink', 'antilinkgc'];
handler.group = true;
handler.admin = true;
handler.botadmin = true;

export default handler;
