
const handler = async (m, { args, command, prefix, updateData }) => {

  const sub = args[0]?.toLowerCase()

  if (sub === 'on') {
    await updateData('groups', m.chat, 'antidelete', 1)
    return m.reply(
      `*Anti-Delete* berhasil diaktifkan!`
    )
  }

  if (sub === 'off') {
    await updateData('groups', m.chat, 'antidelete', 0)
    return m.reply(`*Anti-Delete* dimatikan.`)
  }

  return m.reply(
    `*Anti-Delete Pesan*\n\n` +
    `Fungsi: Bot akan kirim ulang pesan yang dihapus oleh member (non-admin/non-owner)\n\n` +
    `› ${prefix + command} on\n` +
    `› ${prefix + command} off`
  )
}

handler.command = ['antidelete', 'antidel']
handler.group = true
handler.admin = true
handler.botadmin = true

export default handler