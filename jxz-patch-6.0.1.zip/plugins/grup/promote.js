const handler = async (m, { sock, text, usedPrefix, reply }) => {
	let target

	if (m.mentionedJid?.[0]) target = m.mentionedJid[0]
	else if (m.quoted?.sender) target = m.quoted.sender
	else if (text) {
		const clean = text.replace(/[^0-9]/g, '')
		if (clean.length < 5) return reply('Nomor tidak valid!')
		target = clean + '@s.whatsapp.net'
	}

	if (!target) return reply(`Contoh: ${usedPrefix}promote tag/reply/nomor`)

	try {
		await sock.groupParticipantsUpdate(m.chat, [target], 'promote')

		await sock.sendMessage(m.chat, {
			text: `@${target.split('@')[0]} sekarang jadi admin`,
			mentions: [target]
		}, { quoted: m })

	} catch (err) {
		console.error(err)
		reply('Gagal promote!')
	}
}

handler.command = ['promote']
handler.admin = true
handler.group = true
handler.botadmin = true

export default handler