import { bratGen } from 'brat-canvas'

const handler = async (m, { sock, text, usedPrefix, reply }) => {
	const input = text || m.quoted?.text || m.quoted?.body
	if (!input) return reply(`Contoh: ${usedPrefix}brat halo semua`)
	if (input.length > 200) return reply('Teks terlalu panjang! Maksimal 200 karakter.')

	try {
		await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

		const img = await bratGen(input)
		await sock.sendImageAsSticker(m.chat, img, m, {
			packname: `© ${global.namaBot}`,
			author: global.namaOwner
		})

		await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
	} catch (err) {
		console.error(err)
		reply('Gagal membuat brat, coba lagi.')
	}
}

handler.command = ['brat']

export default handler