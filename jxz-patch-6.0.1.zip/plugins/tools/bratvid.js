import { bratVid } from 'brat-canvas/video'

const handler = async (m, { sock, text, usedPrefix, reply }) => {
	const input = text || m.quoted?.text || m.quoted?.body
	if (!input) return reply(`Contoh: ${usedPrefix}bratvid halo semua`)
	if (input.length > 200) return reply('Teks terlalu panjang! Maksimal 200 karakter.')

	try {
		await sock.sendMessage(m.chat, { react: { text: '⏳', key: m.key } })

		const vid = await bratVid(input, {
			outputFormat: 'mp4',
			fast_progress: true,
			lyric: { maxWordPerLayer: 5 }
		})
		await sock.sendVideoAsSticker(m.chat, vid, m, {
			packname: '© ' + global.namaBot,
			author: global.namaOwner
		})

		await sock.sendMessage(m.chat, { react: { text: '✅', key: m.key } })
	} catch (err) {
		console.error(err)
		reply('Gagal membuat bratvid. Pastikan *ffmpeg* terpasang dan coba lagi.')
	}
}

handler.command = ['bratvid']

export default handler