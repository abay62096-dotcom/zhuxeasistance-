import { spawn, exec } from 'child_process'
import { promisify } from 'util'

const execAsync = promisify(exec)

const getYtDlp = async () => {
  const paths = [
    '/home/container/yt-dlp',  // path utama
    'yt-dlp',
    '/usr/local/bin/yt-dlp',
    `${process.env.HOME}/.local/bin/yt-dlp`,
    '/usr/bin/yt-dlp'
  ]
  for (const p of paths) {
    try { await execAsync(`${p} --version`); return p } catch {}
  }
  return null
}

let handler = async (m, { sock, args, command, usedPrefix }) => {
  try {
    if (!args[0]) return m.reply(`Contoh: ${usedPrefix + command} judul lagu`)

    const ytdlp = await getYtDlp()
    if (!ytdlp) return m.reply(`*yt-dlp* belum di install

Untuk menginstal *yt-dlp* via bot:
${usedPrefix}$ curl -L https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -o /tmp/yt-dlp
chmod +x /tmp/yt-dlp
mkdir -p /home/container/.local/bin
mv /tmp/yt-dlp /home/container/.local/bin/yt-dlp`)

    const query = args.join(' ')
    await m.reply('Searching...')

    await new Promise((resolve) => {
      const dl = spawn(ytdlp, [
        '--no-playlist',
        '-f', 'bestaudio',
        '-o', '-',
        '--no-warnings',
        `ytsearch1:${query}`
      ])

      let chunks = []
      let total = 0
      const MAX = 100 * 1024 * 1024
      let stderrLog = ''

      dl.stdout.on('data', chunk => {
        total += chunk.length
        if (total > MAX) { dl.kill(); return }
        chunks.push(chunk)
      })

      dl.stderr.on('data', d => stderrLog += d.toString())

      dl.on('error', err => {
        m.reply(`❌ Spawn error: ${err.message}`)
        resolve()
      })

      dl.on('close', async (code) => {
        try {
          if (total > MAX) return m.reply('❌ Audio terlalu besar. Max 100MB')
          if (code !== 0 || !chunks.length) {
            return m.reply(`❌ Gagal.\nCode: ${code}\nLog: ${stderrLog.slice(-500)}`)
          }

          const buffer = Buffer.concat(chunks)
          await sock.sendMessage(m.chat, {
            audio: buffer,
            mimetype: 'audio/mpeg',
            fileName: `${query}.mp3`,
            ptt: false
          }, { quoted: m })

        } catch (e) { m.reply(e.message) }
        resolve()
      })
    })

  } catch (e) { m.reply(e.message) }
}

handler.command = ['play', 'ytplay']

export default handler