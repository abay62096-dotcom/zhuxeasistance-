/*

  sumber https://codeku.teresav.eu

*/

import { createDecipheriv, randomUUID } from 'crypto';
import { spawn } from 'child_process';
import yts from 'yt-search';
import sharp from 'sharp';
import { prepareWAMessageMedia, generateWAMessageFromContent } from '@whiskeysockets/baileys';

let YTMusic = null;
try {
	({ default: YTMusic } = await import('ytmusic-api'));
} catch {
}

const METADATA_DECRYPTION_KEY = Buffer.from('C5D58EF67A7584E4A29F6C35BBC4EB12', 'hex');

const HEADERS = {
	'Content-Type': 'application/json',
	'Origin': 'https://yt.savetube.me',
	'User-Agent': 'Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/130 Mobile Safari/537.36'
};

const FFMPEG_BITRATE = '16k';
const FFMPEG_SAMPLE_RATE = '24000';
const FFMPEG_CHANNELS = '1';
const FFMPEG_CODEC = 'libopus';
const FFMPEG_FORMAT = 'ogg';

const MAX_ORIGINAL_AUDIO_MB = 25;
const MAX_ORIGINAL_AUDIO_SIZE = MAX_ORIGINAL_AUDIO_MB * 1024 * 1024;

const MAX_COMPRESSED_AUDIO_MB = 6;
const MAX_COMPRESSED_AUDIO_SIZE = MAX_COMPRESSED_AUDIO_MB * 1024 * 1024;

const LRCLIB_API = 'https://lrclib.net/api';
const LRCLIB_USER_AGENT = 'jxzbot-play/1.0 (+https://github.com/)';

async function getLRCLyrics({ title, artist, duration = 0, album = '' }) {
	try {
		if (!title || !artist) return null;

		const params = new URLSearchParams({
			track_name: String(title).trim(),
			artist_name: String(artist).trim()
		});

		if (album) params.set('album_name', String(album).trim());

		const durationNumber = Number(duration);
		if (Number.isFinite(durationNumber) && durationNumber >= 1 && durationNumber <= 3600) {
			params.set('duration', String(Math.round(durationNumber)));
		}

		const res = await fetch(`${LRCLIB_API}/get?${params.toString()}`, {
			headers: { Accept: 'application/json', 'User-Agent': LRCLIB_USER_AGENT }
		});

		if (res.status === 404 || res.status === 429 || !res.ok) return null;

		const data = await res.json();
		if (!data) return null;

		return {
			id: data.id || null,
			trackName: data.trackName || title,
			artistName: data.artistName || artist,
			albumName: data.albumName || '',
			duration: Number(data.duration || duration || 0),
			instrumental: Boolean(data.instrumental),
			plainLyrics: typeof data.plainLyrics === 'string' ? data.plainLyrics : '',
			syncedLyrics: typeof data.syncedLyrics === 'string' ? data.syncedLyrics : ''
		};
	} catch {
		return null;
	}
}

function parseLrcTimestamp(match) {
	if (!match) return null;

	const minutes = Number(match[1]);
	const seconds = Number(match[2]);
	const fractionText = match[3] || '';

	if (!Number.isFinite(minutes) || !Number.isFinite(seconds) || seconds < 0 || seconds >= 60) {
		return null;
	}

	let milliseconds = 0;
	if (fractionText) {
		if (fractionText.length === 1) milliseconds = Number(fractionText) * 100;
		else if (fractionText.length === 2) milliseconds = Number(fractionText) * 10;
		else milliseconds = Number(fractionText.slice(0, 3));
	}

	return minutes * 60 + seconds + milliseconds / 1000;
}

function parseSyncedLyrics(lrc = '') {
	if (!lrc || typeof lrc !== 'string') return [];

	const result = [];
	const lines = lrc.split(/\r?\n/);
	const timestampRegex = /\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?\]/g;

	for (const rawLine of lines) {
		if (!rawLine.trim()) continue;

		const matches = [...rawLine.matchAll(timestampRegex)];
		if (!matches.length) continue;

		const text = rawLine.replace(timestampRegex, '').trim();
		if (!text) continue;

		for (const match of matches) {
			const time = parseLrcTimestamp(match);
			if (time === null || !Number.isFinite(time) || time < 0) continue;
			result.push({ time, text });
		}
	}

	result.sort((a, b) => a.time - b.time);

	const cleaned = [];
	for (const item of result) {
		const last = cleaned[cleaned.length - 1];
		if (last && Math.abs(last.time - item.time) < 0.001 && last.text === item.text) continue;
		cleaned.push(item);
	}

	return cleaned;
}

function plainLyricsToSynced(lyrics = '', duration = 0) {
	if (!lyrics || typeof lyrics !== 'string') return [];

	const lines = lyrics.split(/\r?\n/).map(line => line.trim()).filter(Boolean);
	if (!lines.length) return [];

	const totalDuration = Number(duration);
	let interval = 5;

	if (Number.isFinite(totalDuration) && totalDuration > 0 && lines.length > 1) {
		interval = Math.max(2, Math.min(8, totalDuration / lines.length));
	}

	return lines.map((text, index) => ({ time: index * interval, text }));
}

function normalizeLyrics(lyrics = []) {
	if (!Array.isArray(lyrics)) return [];

	return lyrics
		.filter(item => item && Number.isFinite(Number(item.time)) && typeof item.text === 'string')
		.map(item => ({ time: Number(item.time), text: String(item.text).trim() }))
		.filter(item => item.text)
		.sort((a, b) => a.time - b.time);
}

let ytMusicInstance = null;

async function getYTMusic() {
	if (!YTMusic) return null;
	if (!ytMusicInstance) {
		ytMusicInstance = new YTMusic();
		await ytMusicInstance.initialize();
	}
	return ytMusicInstance;
}

async function searchSong(query) {
	try {
		const ytmusic = await getYTMusic();
		if (ytmusic) {
			const results = await ytmusic.searchSongs(query);
			if (results?.length) {
				const song = results[0];
				return {
					videoId: song.videoId,
					title: song.name,
					artist: song.artist?.name || song.artist || '-',
					album: song.album?.name || '',
					duration: song.duration || 0,
					thumbnail: song.thumbnails?.[song.thumbnails.length - 1]?.url || '',
					url: `https://www.youtube.com/watch?v=${song.videoId}`
				};
			}
		}
	} catch {
	
	}

	const search = await yts(query);
	const video = search?.videos?.[0];
	if (!video) return null;

	return {
		videoId: video.videoId,
		title: video.title,
		artist: video.author?.name || '-',
		album: '',
		duration: video.seconds || 0,
		thumbnail: video.thumbnail || video.image || '',
		url: video.url
	};
}

function escapeHtml(text = '') {
	return String(text)
		.replace(/&/g, '&amp;')
		.replace(/</g, '&lt;')
		.replace(/>/g, '&gt;')
		.replace(/"/g, '&quot;')
		.replace(/'/g, '&#039;');
}

function escapeAttr(text = '') {
	return escapeHtml(text);
}

function formatDuration(seconds = 0) {
	seconds = Number(seconds);
	if (!Number.isFinite(seconds) || seconds <= 0) return '0:00';

	const h = Math.floor(seconds / 3600);
	const m = Math.floor((seconds % 3600) / 60);
	const s = Math.floor(seconds % 60);

	if (h > 0) return h + ':' + String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
	return m + ':' + String(s).padStart(2, '0');
}

async function savetube(url, { downloadType = 'audio', quality = '128kbps' } = {}) {
	const idMatch = url.match(/(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|shorts\/|embed\/))([a-zA-Z0-9_-]{11})/);
	if (!idMatch) throw new Error('URL YouTube tidak valid');

	const videoId = idMatch[1];

	const cdnRes = await fetch('https://media.savetube.vip/api/random-cdn', { headers: HEADERS })
		.then(v => v.json())
		.catch(() => null);

	if (!cdnRes?.cdn) throw new Error('CDN tidak tersedia');
	const cdn = cdnRes.cdn;

	const info = await fetch(`https://${cdn}/v2/info`, {
		method: 'POST',
		headers: HEADERS,
		body: JSON.stringify({ url: `https://www.youtube.com/watch?v=${videoId}` })
	})
		.then(v => v.json())
		.catch(() => null);

	if (!info?.data) throw new Error('Metadata kosong');

	let metadata;
	try {
		const encrypted = Buffer.from(info.data, 'base64');
		const decipher = createDecipheriv('aes-128-cbc', METADATA_DECRYPTION_KEY, encrypted.subarray(0, 16));
		const decrypted = Buffer.concat([decipher.update(encrypted.subarray(16)), decipher.final()]);
		metadata = JSON.parse(decrypted.toString('utf8'));
	} catch {
		throw new Error('Decrypt metadata gagal');
	}

	if (!metadata?.key) throw new Error('Key download tidak ditemukan');

	const dl = await fetch(`https://${cdn}/download`, {
		method: 'POST',
		headers: HEADERS,
		body: JSON.stringify({ id: videoId, downloadType, quality, key: metadata.key })
	})
		.then(v => v.json())
		.catch(() => null);

	if (!dl?.data?.downloadUrl) throw new Error(dl?.message || 'Download gagal');

	return {
		title: metadata.title,
		duration: metadata.durationLabel,
		thumbnail: metadata.thumbnail,
		url: dl.data.downloadUrl
	};
}

async function savetubeRetry(url, opts, retry = 3) {
	let lastErr;
	for (let i = 0; i < retry; i++) {
		try {
			return await savetube(url, opts);
		} catch (e) {
			lastErr = e;
			if (i < retry - 1) await new Promise(resolve => setTimeout(resolve, 1000));
		}
	}
	throw lastErr;
}

async function downloadAudioBuffer(url) {
	if (!url) throw new Error('URL audio kosong');

	const res = await fetch(url, { headers: { 'User-Agent': HEADERS['User-Agent'] } });
	if (!res.ok) throw new Error(`Download audio gagal (${res.status})`);

	const buffer = Buffer.from(await res.arrayBuffer());
	if (!buffer.length || buffer.length > MAX_ORIGINAL_AUDIO_SIZE) {
		throw new Error('Buffer audio bermasalah (kosong atau melebihi 25MB)');
	}

	return buffer;
}

async function compressAudio(inputBuffer) {
	if (!Buffer.isBuffer(inputBuffer) || !inputBuffer.length) {
		throw new Error('Input buffer kosong');
	}

	return new Promise((resolve, reject) => {
		let ffmpeg;
		try {
			ffmpeg = spawn('ffmpeg', [
				'-hide_banner', '-loglevel', 'error',
				'-i', 'pipe:0',
				'-vn',
				'-c:a', FFMPEG_CODEC,
				'-b:a', FFMPEG_BITRATE,
				'-ar', FFMPEG_SAMPLE_RATE,
				'-ac', FFMPEG_CHANNELS,
				'-application', 'audio',
				'-f', FFMPEG_FORMAT,
				'pipe:1'
			], { stdio: ['pipe', 'pipe', 'pipe'] });
		} catch (error) {
			return reject(error);
		}

		const chunks = [];
		let outputSize = 0;
		let finished = false;

		const fail = (error) => {
			if (finished) return;
			finished = true;
			try { ffmpeg.kill('SIGKILL'); } catch {}
			reject(error);
		};

		ffmpeg.stdout.on('data', (chunk) => {
			outputSize += chunk.length;
			if (outputSize > MAX_COMPRESSED_AUDIO_SIZE) return fail(new Error('Audio compress terlalu besar'));
			chunks.push(chunk);
		});

		ffmpeg.stderr.on('data', () => {});

		ffmpeg.on('error', (error) => {
			fail(error?.code === 'ENOENT' ? new Error('FFmpeg tidak ditemukan di server.') : error);
		});

		ffmpeg.on('close', (code) => {
			if (finished) return;
			if (code !== 0) return fail(new Error(`FFmpeg gagal (exit code ${code})`));

			const output = Buffer.concat(chunks);
			if (!output.length) return fail(new Error('FFmpeg menghasilkan audio kosong'));

			finished = true;
			resolve(output);
		});

		ffmpeg.stdin.on('error', (error) => {
			if (error?.code !== 'EPIPE') fail(error);
		});

		ffmpeg.stdin.end(inputBuffer);
	});
}

async function getThumb(url, videoId = null) {
  try {
    // coba maxres dulu kalau ada videoId
    const urls = videoId ? [
      `https://i.ytimg.com/vi/${videoId}/maxresdefault.jpg`,
      `https://i.ytimg.com/vi/${videoId}/sddefault.jpg`,
      `https://i.ytimg.com/vi/${videoId}/hqdefault.jpg`,
      url
    ].filter(Boolean) : [url].filter(Boolean)

    for (const u of urls) {
      try {
        const res = await fetch(u)
        if (!res.ok) continue
        const raw = Buffer.from(await res.arrayBuffer())
        if (raw.length < 5000) continue // skip placeholder kecil
        return await sharp(raw)
          .resize(600, 600, { fit: 'cover', position: 'center' })
          .jpeg({ quality: 90 })
          .toBuffer()
      } catch {}
    }
  } catch {}
  return Buffer.alloc(0)
}

function createMusicPlayer({ title, artist, duration, base64Audio, mime, imageDataUri }) {
	const safeTitle = escapeHtml(title);
	const safeArtist = escapeHtml(artist);
	const safeDuration = escapeHtml(duration || '0:00');
	const safeImage = imageDataUri || 'data:image/svg+xml;base64,PHN2ZyB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciIHdpZHRoPSI0MDAiIGhlaWdodD0iNDAwIj48cmVjdCB3aWR0aD0iNDAwIiBoZWlnaHQ9IjQwMCIgZmlsbD0iIzFhMGQxMiIvPjwvc3ZnPg==';

	return `<style>
  *{margin:0;padding:0;box-sizing:border-box;-webkit-tap-highlight-color:transparent;-webkit-user-select:none;user-select:none;}
  html,body{background:transparent;font-family:-apple-system,BlinkMacSystemFont,'Segoe UI',Roboto,Helvetica,Arial,sans-serif;-webkit-font-smoothing:antialiased;}
  .wrap{padding:10px 8px;}
  .card{position:relative;border-radius:16px;overflow:hidden;background:#121212;}
  .bg-blur{position:absolute;inset:-20px;background-image:url('${escapeAttr(safeImage)}');background-size:cover;background-position:center;filter:blur(60px) saturate(3) brightness(.35);z-index:0;transform:scale(1.2);}
  .overlay{position:absolute;inset:0;background:linear-gradient(160deg,rgba(0,0,0,.2) 0%,rgba(0,0,0,.7) 100%);z-index:1;}
  .body{position:relative;z-index:2;padding:20px 18px 22px;}
  .cover-wrap{width:100%;aspect-ratio:1;border-radius:12px;overflow:hidden;box-shadow:0 20px 50px rgba(0,0,0,.7);margin-bottom:20px;}
  .cover-wrap img{width:100%;height:100%;object-fit:cover;display:block;}
  .meta{margin-bottom:18px;}
  .meta__title{font-size:18px;font-weight:700;color:#fff;line-height:1.25;overflow:hidden;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;}
  .meta__artist{font-size:13px;color:rgba(255,255,255,.6);margin-top:5px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;font-weight:500;}
  .progress-wrap{margin-bottom:6px;}
  .progress-bar{position:relative;height:4px;border-radius:4px;background:rgba(255,255,255,.2);cursor:pointer;touch-action:none;}
  .progress-fill{position:absolute;left:0;top:0;bottom:0;width:0%;border-radius:4px;background:#1db954;transition:width .1s linear;}
  .progress-thumb{position:absolute;top:50%;left:0%;width:12px;height:12px;border-radius:50%;background:#fff;transform:translate(-50%,-50%);box-shadow:0 0 6px rgba(0,0,0,.4);}
  .time-row{display:flex;justify-content:space-between;font-size:11px;color:rgba(255,255,255,.5);margin-bottom:20px;font-variant-numeric:tabular-nums;letter-spacing:.01em;}
  .controls{display:flex;align-items:center;justify-content:center;gap:32px;}
  .ctrl-btn{background:none;border:none;cursor:pointer;padding:0;display:flex;align-items:center;justify-content:center;opacity:.7;transition:opacity .15s;}
  .ctrl-btn:active{opacity:.4;}
  .play-btn{width:56px;height:56px;border-radius:50%;background:#1db954;border:none;cursor:pointer;display:flex;align-items:center;justify-content:center;box-shadow:0 6px 24px rgba(29,185,84,.45);transition:transform .15s,background .15s;flex-shrink:0;}
  .play-btn:active{transform:scale(.93);background:#1aa34a;}
  .play-btn svg{width:22px;height:22px;fill:#000;margin-left:2px;}
  .play-btn.is-pause svg{margin-left:0;}
</style>

<div class="wrap">
  <div class="card">
    <div class="bg-blur"></div>
    <div class="overlay"></div>
    <div class="body">
      <div class="cover-wrap">
        <img src="${escapeAttr(safeImage)}" alt="${escapeAttr(safeTitle)}">
      </div>
      <div class="meta">
        <div class="meta__title">${safeTitle}</div>
        <div class="meta__artist">${safeArtist}</div>
      </div>
      <div class="progress-wrap">
        <div class="progress-bar" id="pb">
          <div class="progress-fill" id="pf"></div>
          <div class="progress-thumb" id="pt"></div>
        </div>
      </div>
      <div class="time-row">
        <span id="cur">0:00</span>
        <span id="dur">${safeDuration}</span>
      </div>
      <div class="controls">
        <button class="ctrl-btn" id="back15" title="Rewind 15s">
          <svg viewBox="0 0 24 24" width="24" height="24" fill="rgba(255,255,255,.7)">
            <path d="M11.99 5V1l-5 5 5 5V7c3.31 0 6 2.69 6 6s-2.69 6-6 6-6-2.69-6-6h-2c0 4.42 3.58 8 8 8s8-3.58 8-8-3.58-8-8-8z"/>
            <text x="7.5" y="15.5" font-size="5" fill="rgba(255,255,255,.7)" font-family="sans-serif" font-weight="bold">15</text>
          </svg>
        </button>
        <button class="play-btn" id="playBtn">
          <svg id="playIcon" viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
        </button>
        <button class="ctrl-btn" id="fwd15" title="Forward 15s">
          <svg viewBox="0 0 24 24" width="24" height="24" fill="rgba(255,255,255,.7)">
            <path d="M18 13c0 3.31-2.69 6-6 6s-6-2.69-6-6 2.69-6 6-6v4l5-5-5-5v4c-4.42 0-8 3.58-8 8s3.58 8 8 8 8-3.58 8-8h-2z"/>
            <text x="7.5" y="15.5" font-size="5" fill="rgba(255,255,255,.7)" font-family="sans-serif" font-weight="bold">15</text>
          </svg>
        </button>
      </div>
    </div>
  </div>
</div>

<audio id="audio" preload="auto" src="data:${mime};base64,${base64Audio}"></audio>

<script>
const audio = document.getElementById('audio');
const playBtn = document.getElementById('playBtn');
const playIcon = document.getElementById('playIcon');
const pf = document.getElementById('pf');
const pt = document.getElementById('pt');
const pb = document.getElementById('pb');
const cur = document.getElementById('cur');

const PLAY_PATH = 'M8 5v14l11-7z';
const PAUSE_PATH = 'M6 19h4V5H6v14zm8-14v14h4V5h-4z';

function fmt(s){s=Math.floor(s||0);return Math.floor(s/60)+':'+String(s%60).padStart(2,'0')}

function setProgress(pct){
  pf.style.width = pct + '%';
  pt.style.left = pct + '%';
}

playBtn.onclick = function(){
  if(audio.paused){
    audio.play();
    playIcon.querySelector('path').setAttribute('d', PAUSE_PATH);
    playBtn.classList.add('is-pause');
  } else {
    audio.pause();
    playIcon.querySelector('path').setAttribute('d', PLAY_PATH);
    playBtn.classList.remove('is-pause');
  }
};

document.getElementById('back15').onclick = function(){ audio.currentTime = Math.max(0, audio.currentTime - 15); };
document.getElementById('fwd15').onclick = function(){ audio.currentTime = Math.min(audio.duration || 0, audio.currentTime + 15); };

audio.ontimeupdate = function(){
  if(audio.duration) setProgress((audio.currentTime/audio.duration)*100);
  cur.textContent = fmt(audio.currentTime);
};

audio.onended = function(){
  playIcon.querySelector('path').setAttribute('d', PLAY_PATH);
  playBtn.classList.remove('is-pause');
  setProgress(0);
  cur.textContent = '0:00';
};

pb.onclick = function(e){
  if(!audio.duration) return;
  const r = pb.getBoundingClientRect();
  audio.currentTime = ((e.clientX - r.left) / r.width) * audio.duration;
};

let dragging = false;
pb.addEventListener('touchstart', function(e){ dragging=true; e.preventDefault(); }, {passive:false});
pb.addEventListener('touchmove', function(e){
  if(!dragging||!audio.duration) return;
  e.preventDefault();
  const r = pb.getBoundingClientRect();
  const pct = Math.min(1, Math.max(0, (e.touches[0].clientX - r.left) / r.width));
  audio.currentTime = pct * audio.duration;
  setProgress(pct*100);
}, {passive:false});
pb.addEventListener('touchend', function(){ dragging=false; }, {passive:true});
</script>`;
}

const handler = async (m, { sock, args, command, usedPrefix }) => {
	if (!args[0]) return m.reply(`Contoh: *${usedPrefix + command} judul lagu*`);

	const query = args.join(' ');
	await m.react('⏳');

	try {
		const song = await searchSong(query);
		if (!song) {
			await m.react('❌');
			return m.reply('❌ Lagu tidak ditemukan.');
		}

		let lyrics = [];
		const lrc = await getLRCLyrics({
			title: song.title,
			artist: song.artist,
			duration: song.duration,
			album: song.album
		});

		if (lrc?.syncedLyrics) {
			lyrics = normalizeLyrics(parseSyncedLyrics(lrc.syncedLyrics));
		} else if (lrc?.plainLyrics) {
			lyrics = normalizeLyrics(plainLyricsToSynced(lrc.plainLyrics, song.duration));
		}

		const dl = await savetubeRetry(song.url, { downloadType: 'audio', quality: '128kbps' });
		const rawAudio = await downloadAudioBuffer(dl.url);

		const compressed = await compressAudio(rawAudio);
		const base64Audio = compressed.toString('base64');

		const thumbBuffer = await getThumb(song.thumbnail || dl.thumbnail, song.videoId)
		const imageDataUri = thumbBuffer.length
			? `data:image/jpeg;base64,${thumbBuffer.toString('base64')}`
			: null;

		const html = createMusicPlayer({
			title: song.title,
			artist: song.artist,
			duration: formatDuration(song.duration) || dl.duration || '0:00',
			base64Audio,
			mime: 'audio/ogg; codecs=opus',
			imageDataUri
		});

		const payload = {
			messageContextInfo: {
				deviceListMetadata: {},
				deviceListMetadataVersion: 2,
				botMetadata: {}
			},
			botForwardedMessage: {
				message: {
					richResponseMessage: {
						messageType: 1,
						submessages: [
							{ messageType: 2, messageText: `🎵 ${song.title} - ${song.artist}` }
						],
						unifiedResponse: {
							data: Buffer.from(
								JSON.stringify({
									response_id: randomUUID(),
									sections: [
										{
											view_model: {
												primitive: {
													__typename: 'GenAIaeacdsnwHtmlPrimitive',
													payload: html,
													trusted_sources: []
												},
												__typename: 'GenAISingleLayoutViewModel'
											}
										}
									]
								})
							).toString('base64')
						},
						contextInfo: {
							forwardingScore: 1,
							isForwarded: true,
							forwardedAiBotMessageInfo: { botJid: '867051314767696@bot' },
							forwardOrigin: 4
						}
					}
				}
			}
		};

		const msg = generateWAMessageFromContent(m.chat, payload, { userJid: sock.user?.id });
		await sock.relayMessage(m.chat, msg.message, { messageId: msg.key.id });

		const editMsg = generateWAMessageFromContent(m.chat, {
			botForwardedMessage: {
				message: {
					protocolMessage: {
						key: { remoteJid: m.chat, fromMe: true, id: msg.key.id },
						type: 14,
						editedMessage: msg.message
					}
				}
			}
		}, { userJid: sock.user?.id });
		await sock.relayMessage(m.chat, editMsg.message, { messageId: editMsg.key.id });

		await m.react('✅');
	} catch (e) {
		console.error('[play] error:', e);
		await m.react('❌');
		return m.reply(`❌ Gagal memutar.\n\nLog: ${e.message}\n\n${e.stack?.slice(0, 300) || ''}`);
	}
};

handler.command = ['play2', 'playrich'];

export default handler;