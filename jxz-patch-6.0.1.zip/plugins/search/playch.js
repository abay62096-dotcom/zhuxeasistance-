import fs from 'fs'
import path from 'path'
import { execSync, spawn, exec } from 'child_process'
import { promisify } from 'util'
import yts from 'yt-search'

const execAsync = promisify(exec)

const AUDIO_CACHE = './data/trash'
if (!fs.existsSync(AUDIO_CACHE)) {
  fs.mkdirSync(AUDIO_CACHE, { recursive: true })
}

const getYtDlp = async () => {
  const paths = [
    '/home/container/yt-dlp',
    'yt-dlp',
    '/usr/local/bin/yt-dlp',
    `${process.env.HOME}/.local/bin/yt-dlp`,
    '/usr/bin/yt-dlp'
  ]
  for (const p of paths) {
    try { await execAsync(`${p} --version`); return p } catch {}
  }
  return null
}

const downloadAudio = async (query) => {
  const search = await yts(query)
  if (!search.videos.length) throw new Error('Lagu tidak ditemukan.')

  const video = search.videos[0]
  const ytdlp = await getYtDlp()
  if (!ytdlp) throw new Error(`yt-dlp tidak ditemukan di server
  
Untuk menginstal *yt-dlp* via bot:
$ curl -L https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -o /tmp/yt-dlp
chmod +x /tmp/yt-dlp
mkdir -p /home/container/.local/bin
mv /tmp/yt-dlp /home/container/.local/bin/yt-dlp`)

  const safeTitle = video.title.replace(/[^a-zA-Z0-9 ]/g, '').trim()
  const fileName = `${safeTitle}_${Date.now()}`
  const rawPath = path.join(AUDIO_CACHE, fileName + '.opus')

  await new Promise((resolve, reject) => {
    const dl = spawn(ytdlp, [
      '--no-playlist',
      '-f', 'bestaudio',
      '-x', '--audio-format', 'opus',
      '-o', rawPath,
      '--no-warnings',
      video.url
    ])

    let stderrLog = ''
    dl.stderr.on('data', d => stderrLog += d.toString())
    dl.on('error', reject)
    dl.on('close', (code) => {
      if (code !== 0 || !fs.existsSync(rawPath)) return reject(new Error(stderrLog.slice(-500) || `exit code ${code}`))
      resolve()
    })
  })

  return {
    path: rawPath,
    title: video.title,
    duration: video.seconds,
    videoUrl: video.url
  }
}

const convertToOggPTT = (inputPath) => {
  const outPath = inputPath.replace(/\.opus$/, '_ptt.ogg')
  execSync(`ffmpeg -y -i "${inputPath}" -avoid_negative_ts make_zero -ac 1 -ar 48000 -c:a libopus -b:a 64k "${outPath}"`, {
    stdio: 'ignore'
  })
  return outPath
}

const generateWaveform = (inputPath, samples = 64) => {
  try {
    const raw = execSync(
      `ffmpeg -i "${inputPath}" -ac 1 -filter:a "aresample=8000" -map 0:a -c:a pcm_s16le -f data -`,
      { maxBuffer: 1024 * 1024 * 50 }
    )
    const data = new Int16Array(raw.buffer, raw.byteOffset, Math.floor(raw.length / 2))
    const blockSize = Math.max(1, Math.floor(data.length / samples))
    const waveform = []
    for (let i = 0; i < samples; i++) {
      let sum = 0
      const start = i * blockSize
      const end = Math.min(start + blockSize, data.length)
      for (let j = start; j < end; j++) sum += Math.abs(data[j])
      const avg = end > start ? sum / (end - start) : 0
      waveform.push(Math.min(100, Math.round((avg / 32768) * 100 * 3)))
    }
    return waveform
  } catch (e) {
    return new Array(64).fill(0).map(() => Math.floor(Math.random() * 40) + 10)
  }
}

const safeDelete = (file) => {
  try { if (file && fs.existsSync(file)) fs.unlinkSync(file) } catch {}
}

const formatDuration = (sec) => {
  sec = parseInt(sec) || 0
  const m = Math.floor(sec / 60)
  const s = sec % 60
  return `${m}:${s.toString().padStart(2, '0')}`
}

const handler = async (m, { sock, args, command, usedPrefix }) => {
  let rawPath = null
  let oggPath = null

  try {
    if (!args[0]) return m.reply(`Example: ${usedPrefix + command} judul lagu`)

    const query = args.join(' ')
    await m.reply('wait...')

    const audio = await downloadAudio(query)
    rawPath = audio.path

    if (!fs.existsSync(rawPath)) throw new Error('File audio tidak ditemukan setelah download.')

    oggPath = convertToOggPTT(rawPath)
    const waveform = generateWaveform(oggPath)
    const buffer = fs.readFileSync(oggPath)

    const { prepareWAMessageMedia, generateMessageIDV2, proto } = await import('@whiskeysockets/baileys')

    const msg = await prepareWAMessageMedia(
      { audio: buffer, mimetype: 'audio/ogg; codecs=opus', ptt: true, waveform },
      { upload: sock.waUploadToServer, jid: '@newsletter' }
    )

    const node = {
      tag: 'message',
      attrs: { to: global.idch, id: generateMessageIDV2(), type: 'media' },
      content: [
        { tag: 'meta', attrs: { contenttype: 'audio' } },
        { tag: 'plaintext', attrs: { mediatype: 'audio' }, content: proto.Message.encode(msg).finish() }
      ]
    }

    await sock.query(node)

    const meta = await sock.newsletterMetadata("jid", global.idch)
    const link = `https://whatsapp.com/channel/${meta.thread_metadata.invite}`

    m.reply(`*${audio.title}* berhasil diupload ke channel!\n\n> result: ${link}`)

  } catch (e) {
    m.reply(`*ERROR!*\n\n${e.message}`)
  } finally {
    safeDelete(rawPath)
    safeDelete(oggPath)
  }
}

handler.command = ['playch', 'pch']
handler.owner = true;
handler.noJadiBot = true

export default handler