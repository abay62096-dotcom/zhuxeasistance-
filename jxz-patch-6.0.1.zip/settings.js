/*

  WhatsApp bot base || Zhuxee-Asistance 
  WhatsApp bot dengan library Baileys & runtime di NodeJs
  
  * Creator : Abay
  * Follow : https://whatsapp.com/channel/0029VbBoflt4dTnNWXV4zC09

 Jangan lupa baca README.md & EXAMPLE.js yaa

*/

import fs from 'fs';
import chalk from 'chalk';
import { fileURLToPath, pathToFileURL } from 'url';

const __filename = fileURLToPath(import.meta.url);

/*============= MAIN INFO =============*/
global.owner = ['628139614117'];
global.namaOwner = 'Abay';
global.namaBot = 'Zhuxee-Asistance';
global.versi = '6.0.1';
global.typeSc = 'plugins manager';
global.module = 'ECMAScript Module (ESM)';
global.data = 'LocalJSON';
global.rtBot = 'NodeJS';
global.library = 'Baileys';
global.url = 'https://t.me/xzpanels_bot';

/*============== ID CH KALIAN ==============*/ 
global.idch = "120363411497252643@newsletter"

/*============== THUMBNAIL ==============*/
global.thumbnail = 'https://raw.githubusercontent.com/abay62096-dotcom/Zhuxee-Asistance/refs/heads/main/Zhuxee-Aisstnace.jpg';
global.fotoreply = 'https://raw.githubusercontent.com/abay62096-dotcom/Zhuxee-Asistance/refs/heads/main/Zhuxee%E7%88%B6.jpg'

/*============== LIMIT ==============*/
global.limit = 10;

global.bot = true
global.mainSock = null

global.ghTokens = "";
global.userGh = "";

global.mess = {
	owner: 'Sorry, this feature is for owners only!',
	mainOwner: 'Sorry, this feature is only for the main bot owner!',
	admin: 'Sorry, this feature is only for group admins!',
	botAdmin: 'Bot must be admin, in this group!',
	group: 'Can only be used within groups!',
	sewa: 'Sorry, this feature is only for premium users!',
	vip: 'Sorry, this feature is only for owners & premium users!',
	private: 'Use in private chat!',
};

fs.watchFile(__filename, () => {
	fs.unwatchFile(__filename);
	console.log(chalk.white.bold('~> Update File :'), chalk.green.bold(__filename));
	import(`${pathToFileURL(__filename).href}?update=${Date.now()}`);
});