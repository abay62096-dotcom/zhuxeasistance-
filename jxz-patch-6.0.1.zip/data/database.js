/*

  WhatsApp bot base || Zhuxee-Asistance 
  WhatsApp bot dengan library Baileys & runtime di NodeJs
  
  * Creator : Abay
  * Follow : https://whatsapp.com/channel/0029VbBoflt4dTnNWXV4zC09

 Jangan lupa baca README.md & EXAMPLE.js yaa

*/

import fs from 'fs';
import path from 'path';

const DB_PATH = path.join(process.cwd(), 'data', 'database.json');
export const JADIBOT_DB_DIR = path.join(process.cwd(), 'data', 'jadibot');

const LEGACY_NOPREFIX = path.join(process.cwd(), 'data', 'noprfx.json');
const LEGACY_MENU_CONFIG = path.join(process.cwd(), 'data', 'menu-config.json');
const LEGACY_POLL_CMDS = path.join(process.cwd(), 'data', 'pollcmd.json');
const LEGACY_VOTE_KICKS = path.join(process.cwd(), 'data', 'votekick.json');

const readJsonIfExists = (p, fallback) => {
	try {
		if (!fs.existsSync(p)) return fallback;
		return JSON.parse(fs.readFileSync(p, 'utf-8')) ?? fallback;
	} catch (e) {
		console.error(`[DB] Gagal parse ${p}, abaikan:`, e.message);
		return fallback;
	}
};

const DEFAULT_DB = {
	users: {},
	groups: {},
	settings: {
		bot: {
			id: 'bot',
			prefix: '.',
			multiprefix: 0,
			public: 1,
			regis: 0,
		},
	},
	noprefix: false,
	menuConfig: { type: 'text' },
	pollCommands: {},
	voteKicks: {},
};

const SETTING_KEYS = ['public', 'prefix', 'multiprefix', 'noPrefix', 'regis'];

const readSettings = (db) => {
	const b = { ...DEFAULT_DB.settings.bot, ...(db.settings?.bot || {}) };
	return {
		public: b.public === 1,
		prefix: b.prefix || '.',
		multiprefix: b.multiprefix === 1,
		regis: b.regis === 1,
		noPrefix: db.noprefix === true,
	};
};

const LIMIT_RESET_MS = 24 * 60 * 60 * 1000;

const getDefaultLimit = () => {
	const n = Number(global.limit);
	return Number.isFinite(n) && n >= 0 ? Math.floor(n) : 10;
};

const DEFAULT_USER = (jid, name) => ({
	id: jid,
	name: name || '',
	limit_val: getDefaultLimit(),
	limit_reset: Date.now(),
	registered: 0,
	reg_name: '',
	reg_time: 0,
	balance: 1000,
	premium: 0,
	health: 100,
	stamina: 100,
	level: 1,
	exp: 0,
	role: 'Warga',
	potion: 0,
	iron: 0,
	gold: 0,
	diamond: 0,
	common_crate: 0,
	sword: 0,
});

const DEFAULT_GROUP = (jid) => ({
	id: jid,
	mute: 0,
	welcome: 0,
	goodbye: 0,
	antilink: 0,
	antidelete: 0,
	antiviewonce: 0,
	antitoxic: 0,
	antibot: 0,
	antisticker: 0,
	rpg_mode: 1,
	gcbypass: 0,
});

const _instances = new Set();
const flushAll = () => { for (const inst of _instances) inst.flush(); };
process.on('exit', flushAll);
for (const sig of ['SIGINT', 'SIGTERM']) {
	process.on(sig, () => { flushAll(); process.exit(0); });
}

const createDatabase = (filePath, { legacy = false, label = 'database' } = {}) => {
	let _db = null;
	let _saveTimer = null;
	let _destroyed = false;
	let botSet = null;

	const writeNow = () => {
		if (_destroyed || !_db) return;
		try {
			fs.writeFileSync(filePath, JSON.stringify(_db, null, 2));
		} catch (e) {
			console.error(`[DB:${label}] Gagal save:`, e.message);
		}
	};

	const loadDb = () => {
		if (_db) return _db;

		if (!fs.existsSync(path.dirname(filePath))) {
			fs.mkdirSync(path.dirname(filePath), { recursive: true });
		}

		if (!fs.existsSync(filePath)) {
			_db = structuredClone(DEFAULT_DB);
			writeNow();
		} else {
			try {
				_db = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
				if (!_db.users) _db.users = {};
				if (!_db.groups) _db.groups = {};
				if (!_db.settings) _db.settings = {};
				if (!_db.settings.bot) _db.settings.bot = structuredClone(DEFAULT_DB.settings.bot);

				if (!Object.prototype.hasOwnProperty.call(_db, 'noprefix')) {
					const old = legacy ? readJsonIfExists(LEGACY_NOPREFIX, null) : null;
					_db.noprefix = old && typeof old.enabled === 'boolean' ? old.enabled : false;
				}
				if (!_db.menuConfig || typeof _db.menuConfig !== 'object') {
					_db.menuConfig = (legacy ? readJsonIfExists(LEGACY_MENU_CONFIG, { type: 'text' }) : null) || { type: 'text' };
				}
				if (!_db.pollCommands || typeof _db.pollCommands !== 'object') {
					_db.pollCommands = (legacy ? readJsonIfExists(LEGACY_POLL_CMDS, {}) : null) || {};
				}
				if (!_db.voteKicks || typeof _db.voteKicks !== 'object') {
					_db.voteKicks = (legacy ? readJsonIfExists(LEGACY_VOTE_KICKS, {}) : null) || {};
				}
				writeNow();
			} catch (e) {
				console.error(`[DB:${label}] Gagal parse ${path.basename(filePath)}, reset ke default:`, e.message);
				_db = structuredClone(DEFAULT_DB);
			}
		}
		return _db;
	};

	const saveDb = () => {
		if (_destroyed) return;
		if (_saveTimer) clearTimeout(_saveTimer);
		_saveTimer = setTimeout(writeNow, 1500);
	};

	botSet = readSettings(loadDb());

	const initDb = () => {
		loadDb();
		console.log(`[DB] ${path.basename(filePath)} loaded`);
		return Promise.resolve();
	};

	const setSetting = (key, value) => {
		if (!SETTING_KEYS.includes(key)) throw new Error('Invalid setting: ' + key);
		const db = loadDb();
		botSet[key] = key === 'prefix' ? String(value || '.') : !!value;
		if (key === 'noPrefix') {
			db.noprefix = botSet.noPrefix;
		} else {
			db.settings.bot[key] = key === 'prefix' ? botSet.prefix : botSet[key] ? 1 : 0;
		}
		saveDb();
		return botSet[key];
	};

	const getUser = (jid, name) => {
		const db = loadDb();
		if (!db.users[jid]) {
			db.users[jid] = DEFAULT_USER(jid, name);
			saveDb();
		}
		return Promise.resolve(db.users[jid]);
	};

	const getGroup = (jid) => {
		const db = loadDb();
		if (!db.groups[jid]) {
			db.groups[jid] = DEFAULT_GROUP(jid);
			saveDb();
		}
		return Promise.resolve(db.groups[jid]);
	};

	const updateData = (table, id, column, value) => {
		if (!['users', 'groups', 'settings'].includes(table)) {
			return Promise.reject(new Error('Invalid table: ' + table));
		}
		const db = loadDb();
		if (!db[table][id]) {
			if (table === 'users') db[table][id] = DEFAULT_USER(id, '');
			else if (table === 'groups') db[table][id] = DEFAULT_GROUP(id);
			else db[table][id] = { id };
		}
		db[table][id][column] = value;
		if (table === 'settings' && id === 'bot') Object.assign(botSet, readSettings(db));
		saveDb();
		return Promise.resolve(1);
	};

	const incrementData = (table, id, column, value) => {
		if (!['users', 'groups'].includes(table)) {
			return Promise.reject(new Error('Invalid table: ' + table));
		}
		const db = loadDb();
		if (!db[table][id]) {
			if (table === 'users') db[table][id] = DEFAULT_USER(id, '');
			else db[table][id] = DEFAULT_GROUP(id);
		}
		db[table][id][column] = (db[table][id][column] || 0) + value;
		saveDb();
		return Promise.resolve(1);
	};

	const _ensureUser = (jid) => {
		const db = loadDb();
		if (!db.users[jid]) db.users[jid] = DEFAULT_USER(jid, '');
		const u = db.users[jid];
		const now = Date.now();
		if (!u.limit_reset || now - u.limit_reset >= LIMIT_RESET_MS) {
			u.limit_val = getDefaultLimit();
			u.limit_reset = now;
			saveDb();
		}
		return u;
	};

	const getLimitInfo = (jid) => {
		const u = _ensureUser(jid);
		return {
			limit: u.limit_val,
			max: getDefaultLimit(),
			resetIn: Math.max(0, u.limit_reset + LIMIT_RESET_MS - Date.now()),
		};
	};

	const useLimit = (jid, amount = 1) => {
		const u = _ensureUser(jid);
		const resetIn = Math.max(0, u.limit_reset + LIMIT_RESET_MS - Date.now());
		if ((u.limit_val || 0) < amount) return { ok: false, limit: u.limit_val || 0, resetIn };
		u.limit_val -= amount;
		saveDb();
		return { ok: true, limit: u.limit_val, resetIn };
	};

	const refundLimit = (jid, amount = 1) => {
		const u = _ensureUser(jid);
		u.limit_val = Math.min((u.limit_val || 0) + amount, getDefaultLimit());
		saveDb();
		return u.limit_val;
	};

	const isRegistered = (jid) => {
		const db = loadDb();
		return db.users[jid]?.registered === 1;
	};

	const registerUser = (jid, name) => {
		const db = loadDb();
		if (!db.users[jid]) db.users[jid] = DEFAULT_USER(jid, name);
		const u = db.users[jid];
		u.registered = 1;
		u.reg_name = name;
		u.reg_time = Date.now();
		u.name = name;
		saveDb();
		return u;
	};

	const getSettings = () => {
		const db = loadDb();
		return Promise.resolve(db.settings?.bot || DEFAULT_DB.settings.bot);
	};

	const getMutedGroups = () => {
		const db = loadDb();
		return Promise.resolve(
			Object.values(db.groups)
				.filter((v) => v.mute === 1)
				.map((v) => ({ id: v.id }))
		);
	};

	const getAllBypassGroups = () => {
		const db = loadDb();
		return Promise.resolve(
			Object.values(db.groups)
				.filter((v) => v.gcbypass === 1)
				.map((v) => ({ id: v.id }))
		);
	};

	const isGroupBypassed = (jid) => {
		const db = loadDb();
		return Promise.resolve(db.groups?.[jid]?.gcbypass === 1);
	};

	const getNoPrefix = () => botSet.noPrefix === true;
	const setNoPrefix = (val) => setSetting('noPrefix', val === true);

	const getMenuConfig = () => {
		const db = loadDb();
		if (!db.menuConfig || typeof db.menuConfig !== 'object') db.menuConfig = { type: 'text' };
		return db.menuConfig;
	};
	const setMenuConfig = (data) => {
		const db = loadDb();
		db.menuConfig = data && typeof data === 'object' ? data : { type: 'text' };
		saveDb();
		return db.menuConfig;
	};

	const getPollCommands = () => {
		const db = loadDb();
		if (!db.pollCommands || typeof db.pollCommands !== 'object') db.pollCommands = {};
		return db.pollCommands;
	};

	const getVoteKicks = () => {
		const db = loadDb();
		if (!db.voteKicks || typeof db.voteKicks !== 'object') db.voteKicks = {};
		return db.voteKicks;
	};

	const saveDatabase = () => {
		if (loadDb()) saveDb();
	};

	const raw = () => loadDb();

	const flush = () => {
		if (_saveTimer) clearTimeout(_saveTimer);
		writeNow();
	};

	const destroy = () => {
		_instances.delete(api);
		_destroyed = true;
		if (_saveTimer) clearTimeout(_saveTimer);
		try { if (fs.existsSync(filePath)) fs.rmSync(filePath, { force: true }); } catch {}
	};

	const api = {
		filePath, botSet, raw, flush, destroy, setSetting,
		initDb, getUser, getGroup, updateData, incrementData, getSettings,
		getMutedGroups, getAllBypassGroups, isGroupBypassed,
		getNoPrefix, setNoPrefix, getMenuConfig, setMenuConfig,
		getPollCommands, getVoteKicks, saveDatabase,
		getLimitInfo, useLimit, refundLimit,
		isRegistered, registerUser,
	};
	_instances.add(api);
	return api;
};

const mainDb = createDatabase(DB_PATH, { legacy: true, label: 'main' });

const createJadibotDatabase = (number) =>
	createDatabase(path.join(JADIBOT_DB_DIR, `${String(number).replace(/[^0-9]/g, '')}.json`), { label: `jadibot:${number}` });

const { initDb, getUser, getGroup, updateData, incrementData, getSettings, getMutedGroups, getAllBypassGroups, isGroupBypassed, getNoPrefix, setNoPrefix, getMenuConfig, setMenuConfig, getPollCommands, getVoteKicks, saveDatabase, getLimitInfo, useLimit, refundLimit, isRegistered, registerUser } = mainDb;

export { createDatabase, createJadibotDatabase, mainDb, initDb, getUser, getGroup, updateData, incrementData, getSettings, getMutedGroups, getAllBypassGroups, isGroupBypassed, getNoPrefix, setNoPrefix, getMenuConfig, setMenuConfig, getPollCommands, getVoteKicks, saveDatabase, getLimitInfo, useLimit, refundLimit, isRegistered, registerUser };