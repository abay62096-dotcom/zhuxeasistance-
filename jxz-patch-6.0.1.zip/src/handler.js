/*

  WhatsApp bot base || Zhuxee-Asistance 
  WhatsApp bot dengan library Baileys & runtime di NodeJs
  
  * Creator : Abay
  * Follow : https://whatsapp.com/channel/0029VbBoflt4dTnNWXV4zC09

 Jangan lupa baca README.md & EXAMPLE.js yaa

*/

process.on('uncaughtException', (err) => {
	console.error('Caught exception:', err);
});

import '../lib/import.js';

import sharp from 'sharp'
import * as fsSync from 'fs';
import chalk from 'chalk';
import { pathToFileURL } from 'url';

import { handleMessage, getPluginStats, getMenuData } from './plugins.js';

const owners = JSON.parse(fsSync.readFileSync('./data/owner.json'));
const premium = JSON.parse(fsSync.readFileSync('./data/prem.json'));

export async function handler_cmd(sock, m, chatUpdate) {
	if (sock.resolveMJids) await sock.resolveMJids(m);

	const body = (
		m.mtype === 'conversation' ? m.message.conversation
		: m.mtype === 'imageMessage' ? m.message.imageMessage.caption
		: m.mtype === 'videoMessage' ? m.message.videoMessage.caption
		: m.mtype === 'extendedTextMessage' ? m.message.extendedTextMessage.text
		: m.mtype === 'buttonsResponseMessage' ? m.message.buttonsResponseMessage.selectedButtonId
		: m.mtype === 'listResponseMessage' ? m.message.listResponseMessage.singleSelectReply.selectedRowId
		: m.mtype === 'templateButtonReplyMessage' ? m.message.templateButtonReplyMessage.selectedId
		: m.mtype === 'interactiveResponseMessage' ? JSON.parse(m.msg.nativeFlowResponseMessage.paramsJson).id
		: ''
	) || '';

	try {
		const isJadiBot = !!(m.isJadiBot || sock.isJadiBot);
		const db = sock.db || global.mainDb;
		const botSet = sock.botSet || db.botSet;

		const botNumber = sock.decodeJid(sock.user.id);
		
		const normNum = (v) => String(v || '').replace(/[^0-9]/g, '');
		const senderNum = sock.normJid ? sock.normJid(m.sender) : normNum(m.sender);

		const globalOwners = (global.owner || []).map(normNum);
		const ownerNums = [normNum(botNumber), ...globalOwners, ...owners.map(normNum)];
		const isOwner = ownerNums.includes(senderNum) || m.fromMe;

		const mainBotNum = global.mainSock?.user?.id ? normNum(global.mainSock.decodeJid(global.mainSock.user.id)) : '';
		const mainOwnerNums = [mainBotNum, ...globalOwners, ...owners.map(normNum)].filter(Boolean);
		const isMainOwner = isJadiBot ? mainOwnerNums.includes(senderNum) : isOwner;

		const premiumNums = premium.map(normNum);
		const isPremium = premiumNums.includes(senderNum) || m.isDeveloper;

		const globalPrefix = botSet.prefix || '.';
        const prefixRegex = /^[°•π÷×¶∆£¢€¥®™+✓_=|~!?@#%^&.©^]/gi;
        const isStrictMode = botSet.multiprefix === true;

        let prefix = '';
        let isCmd = false;

        if (!body) {
            isCmd = false;
        } else if (botSet.noPrefix && isOwner) {
            const matchPrefix = body.match(prefixRegex);
            if (matchPrefix) {
                prefix = matchPrefix[0];
                isCmd = true;
            } else {
                prefix = '';
                isCmd = true;
            }
        } else if (isStrictMode) {
            if (body.startsWith(globalPrefix)) { prefix = globalPrefix; isCmd = true; }
        } else {
            const match = body.match(prefixRegex);
            if (match) {
                prefix = match[0];
                isCmd = true;
            } else {
                prefix = '';
                isCmd = true;
            }
        }
        
		const command = isCmd ? body.slice(prefix.length).trim().split(' ').shift().toLowerCase() : '';
		const args = isCmd ? body.slice(prefix.length).trim().split(/ +/).slice(1) : [];
		const text = args.join(' ');
		const quoted = m.quoted ? m.quoted : m;
		const mime = quoted?.msg?.mimetype || quoted?.mimetype || null;
		const qmsg = m.quoted || m;

		const groupMetadata = m.isGroup ? await sock.getCachedGroupMetadata(m.chat).catch(() => ({})) : {};
		const normalizeNum = (j) => sock.normJid ? sock.normJid(j) : (j?.split('@')[0]?.split(':')[0] || '');

		const participants = m.isGroup ? (groupMetadata.participants?.map((p) => {
			let admin = null;
			if (p.admin === 'superadmin') admin = 'superadmin';
			else if (p.admin === 'admin') admin = 'admin';
			const idJid = p.id || '';
			const identities = [idJid, p.jid, p.lid, p.phoneNumber]
				.filter(Boolean)
				.map(normalizeNum);
			return { jid: idJid, identities: [...new Set(identities)], admin };
		}) || []) : [];

		const groupAdminsData = m.isGroup ? participants.filter(p => p.admin === 'admin' || p.admin === 'superadmin') : [];
		const groupAdmins = groupAdminsData.map(p => p.jid);
		const botIds = [sock.user?.id, sock.user?.lid].filter(Boolean).map(normalizeNum);
        const isBotAdmin = m.isGroup ? groupAdminsData.some(p => p.identities.some(i => botIds.includes(i))) : false;
		const isAdmin = m.isGroup ? groupAdminsData.some(p => p.identities.includes(normalizeNum(m.sender))) : false;

		const chatDb = m.isGroup ? await db.getGroup(m.chat) : null;
		if (m.isGroup && isCmd && chatDb?.mute === 1 && !isOwner) return;

        const rawBuffer = await global.getBuffer(global.fotoreply);
        const thumbnailBuffer = await sharp(rawBuffer).resize(200, 200).jpeg({ quality: 60 }).toBuffer();
    
		const reply = (m.reply = async (teks) => {
        return sock.sendMessage(m.chat, {
           document: rawBuffer,
           fileName: "元 - zhuxee",
           mimetype: "image/png",
           fileLength: 1,
           jpegThumbnail: thumbnailBuffer,
           caption: teks,
           contextInfo: {
             mentionedJid: [m.sender]
           }
        }, { quoted: m });
	  });

		const example = (teks) => `Cara pengguna:\n*${prefix + command}* ${teks}`;

		const isGcBypassed = m.isGroup && chatDb?.gcbypass === 1;

		const handleData = {
			text, args, isCmd, mime, qmsg,
			isOwner, isMainOwner, command, reply, example, prefix,
			isBotAdmin, isAdmin, owners, premium, isPremium,
			getPluginStats,
			getMenuData: () => getMenuData({ jadibot: isJadiBot }),
			db, botSet,
			setSetting: db.setSetting,
			getUser: db.getUser,
			getGroup: db.getGroup,
			updateData: db.updateData,
			incrementData: db.incrementData,
			getSettings: db.getSettings,
			getMutedGroups: db.getMutedGroups,
			getAllBypassGroups: db.getAllBypassGroups,
			isGroupBypassed: db.isGroupBypassed,
			getNoPrefix: db.getNoPrefix,
			setNoPrefix: db.setNoPrefix,
			getMenuConfig: db.getMenuConfig,
			setMenuConfig: db.setMenuConfig,
			getPollCommands: db.getPollCommands,
			getVoteKicks: db.getVoteKicks,
			saveDatabase: db.saveDatabase,
			isGcBypassed,
			isJadiBot,
		};

		if (isCmd && !botSet.public && !isOwner && !isGcBypassed) return;

		await handleMessage(m, sock, isCmd ? handleData.command.toLowerCase() : '', handleData);

		if (isCmd) {
			const from = m.key.remoteJid;
			const chatType = from.endsWith('@g.us') ? 'GROUP' : 'PRIVATE';
			console.log(
				chalk.green.bold(`\n [ bot ] - cmd actived`) +
				chalk.white.bold(`\n  ├ message:   `) + chalk.yellow.bold(`${prefix}${command}`) +
				chalk.white.bold(`\n  ├ chat In:   `) + chalk.magenta(chatType) +
				chalk.white.bold(`\n  ├ name:      `) + chalk.cyan(m.pushName || 'N/A') +
				chalk.white.bold(`\n  └ sender ID: `) + chalk.blue(m.sender) + '\n'
			);
		}

	} catch (err) {
		console.log(err);
		try {
			if (sock?.sendMessage && global.owner) {
				await sock.sendMessage(global.owner + '@s.whatsapp.net', { text: err.toString() }, { quoted: m });
			}
		} catch (_) {}
	}
}

fsSync.watchFile(__filename, () => {
	fsSync.unwatchFile(__filename);
	console.log(chalk.white.bold('~> Update File :'), chalk.green.bold(__filename));
	import(`${pathToFileURL(__filename).href}?update=${Date.now()}`);
});