/*

  WhatsApp bot base || Zhuxee-Asistance 
  WhatsApp bot dengan library Baileys & runtime di NodeJs
  
  * Creator : Abay
  * Follow : https://whatsapp.com/channel/0029VbBoflt4dTnNWXV4zC09

 Jangan lupa baca README.md & EXAMPLE.js yaa

*/

import '../lib/import.js';

import fs from 'fs';
import path from 'path';
import { pathToFileURL } from 'url';

let _pluginCache = null;
let _pluginMap = new Map();
const _fileCache = new Map();

const _errCooldown = new Map();
const _notifyOwner = (pluginPath, err) => {
	if (!global.mainSock || !global.owner?.[0]) return;
	const errMsg = err?.message || String(err);
	const key = pluginPath + errMsg.slice(0, 40);
	const now = Date.now();
	if (_errCooldown.has(key) && now - _errCooldown.get(key) < 60_000) return;
	_errCooldown.set(key, now);
	const stack = err?.stack || '';
	const line = stack.split('\n').find(l => l.includes('.js') && !l.includes('node_modules') && !l.includes('plugins.js'));
	const lineNum = line?.match(/:([0-9]+):[0-9]+/)?.[1];
	const lineInfo = lineNum ? `\nlines: *${lineNum}*` : '';
	const text = `*Plugin error:*

- *[path plugins]* : ${pluginPath}
- *[detail error]* :

\`\`\`${errMsg}${lineInfo}\`\`\``;
	global.mainSock.sendMessage(global.owner[0] + '@s.whatsapp.net', { text }).catch(() => {});
};

const _scanDir = async (dir) => {
	const plugins = [];
	if (!fs.existsSync(dir)) return plugins;

	const files = fs.readdirSync(dir);
	for (const file of files) {
		const filePath = path.join(dir, file);
		const stat = fs.statSync(filePath);

		if (stat.isDirectory()) {
			plugins.push(...await _scanDir(filePath));
		} else if (filePath.endsWith('.js')) {
			const cached = _fileCache.get(filePath);

			if (cached && cached.mtime === stat.mtimeMs) {
				plugins.push(cached.plugin);
				for (const cmd of (cached.plugin.command || [])) {
					_pluginMap.set(cmd.toLowerCase(), cached.plugin);
				}
				continue;
			}

			try {
				const pluginUrl = `${pathToFileURL(filePath).href}?update=${stat.mtimeMs}`;
				const pluginModule = await import(pluginUrl);
				const plugin = pluginModule.default || pluginModule;

				if (typeof plugin === 'function' && Array.isArray(plugin.command)) {
					plugins.push(plugin);
					_fileCache.set(filePath, { mtime: stat.mtimeMs, plugin, folder: path.basename(path.dirname(filePath)) });
					for (const cmd of plugin.command) {
						_pluginMap.set(cmd.toLowerCase(), plugin);
					}
				}
			} catch (err) {
				console.error(`[PLUGIN] Gagal memuat '${filePath}':`, err.message);
				_notifyOwner(`plugins/${path.relative(process.cwd() + '/plugins', filePath)}`, err);
			}
		}
	}
	return plugins;
};

export const loadPlugins = async (dir = path.join(process.cwd(), 'plugins'), forceReload = false) => {
	if (_pluginCache && !forceReload) return _pluginCache;
	if (!fs.existsSync(dir)) {
		_pluginCache = [];
		return _pluginCache;
	}
	const plugins = await _scanDir(dir);
	_pluginCache = plugins;
	return plugins;
};

export const reloadPlugins = async () => {
	_pluginCache = null;
	_pluginMap.clear();
	_fileCache.clear();
	return await loadPlugins(path.join(process.cwd(), 'plugins'), true);
};

const POLL_INTERVAL = 3000; 
const _getSnapshot = (baseDir) => {
	const snapshot = new Map();
	if (!fs.existsSync(baseDir)) return snapshot;
	const scan = (dir) => {
		for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
			const fullPath = path.join(dir, entry.name);
			if (entry.isDirectory()) scan(fullPath);
			else if (entry.name.endsWith('.js')) snapshot.set(fullPath, fs.statSync(fullPath).mtimeMs);
		}
	};
	scan(baseDir);
	return snapshot;
};

export const startWatcher = () => {
	const baseDir = path.join(process.cwd(), 'plugins');
	let lastSnapshot = _getSnapshot(baseDir);

	setInterval(async () => {
		const current = _getSnapshot(baseDir);
		let changed = false;

		for (const [f, mtime] of current) {
			if (!lastSnapshot.has(f) || lastSnapshot.get(f) !== mtime) { changed = true; break; }
		}
		if (!changed) {
			for (const f of lastSnapshot.keys()) {
				if (!current.has(f)) { _fileCache.delete(f); changed = true; break; }
			}
		}

		if (changed) {
			lastSnapshot = current;
			try {
				await reloadPlugins();
				console.log(`[Plugins] reload — ${_pluginMap.size} command terdaftar`);
			} catch (err) {
				console.error(`[PLUGIN] Gagal reload:`, err.message);
				_notifyOwner('reload', err);
			}
		}
	}, POLL_INTERVAL);
};

const checkPermission = (plugin, m, Obj) => {
	const { isOwner, isMainOwner, isAdmin, isBotAdmin, isPremium } = Obj;

    if (plugin.noJadiBot && (m.isJadiBot || Obj?.sock?.isJadiBot)) {
	const isClone = global.isCloneBot?.(Obj?.sock?.user?.id);
	if (!isClone) { 
	  m.reply('Fitur ini tidak bisa digunakan oleh *jadibot*!')
	  return false; 
	  }
	}
	
	if (plugin.mainOwner && !isMainOwner) { 
	 m.reply('Sorry, this feature is only for the main bot owner!'); 
	 return false; 
	}

	if (plugin.owner && !isOwner) { 
	 m.reply(mess.owner); 
	 return false; 
	}
	
	if (plugin.premium && !isPremium && !isOwner) {
	 m.reply(mess.vip); 
	 return false; 
	}
	
	if (plugin.group && !m.isGroup) { 
	 m.reply(mess.group); 
	 return false; 
	}
	
	if (plugin.private && m.isGroup) { 
	 m.reply(mess.private); 
	 return false; 
	}
	
	if (plugin.admin && m.isGroup && !isAdmin && !isOwner) { 
	 m.reply(mess.admin); 
	 return false; 
	}
	
	if (plugin.botadmin && !isBotAdmin) { 
	 m.reply(mess.botAdmin); 
	 return false; 
	}
	
	return true;
};

const formatDuration = (ms) => {
	const total = Math.ceil(ms / 1000);
	const h = Math.floor(total / 3600);
	const mnt = Math.floor((total % 3600) / 60);
	const d = total % 60;
	if (h > 0) return `${h} jam ${mnt} menit`;
	if (mnt > 0) return `${mnt} menit ${d} detik`;
	return `${d} detik`;
};

export const handleMessage = async (m, sock, commandText, Obj) => {
	if (!_pluginCache) await loadPlugins();

	for (const plugin of _pluginCache) {
		if (typeof plugin.before === 'function') {
			if (plugin.noJadiBot && (m.isJadiBot || sock?.isJadiBot)) continue;
			try {
				const { prefix: usedPrefix, ...restOfObj } = Obj;
				await plugin.before(m, { sock, usedPrefix, ...restOfObj });
			} catch (e) {
				console.error(`[BEFORE] Error:`, e.message);
			}
		}
	}

	if (typeof commandText !== 'string' || commandText.length === 0) return;

	const plugin = _pluginMap.get(commandText.toLowerCase());
	if (plugin) {
		let limitUsed = false;
		const { prefix: usedPrefix, ...restOfObj } = Obj;
		const pluginData = { sock, usedPrefix, ...restOfObj };
		try {
			if (pluginData.botSet?.regis && !pluginData.isOwner && !plugin.noregis && typeof pluginData.db?.isRegistered === 'function' && !pluginData.db.isRegistered(m.sender)) {
				return m.reply(`*Kamu belum terdaftar!*

Daftar dengan cara:
*${usedPrefix}daftar nama*`);
			}

			const allowed = checkPermission(plugin, m, pluginData);
			if (!allowed) return;

			if (plugin.limit === true && !pluginData.isOwner && !pluginData.isPremium && typeof pluginData.db?.useLimit === 'function') {
				const res = pluginData.db.useLimit(m.sender, 1);
				if (!res.ok) {
					return m.reply(`Limit harian kamu sudah habis!\n\nLimit akan di-reset dalam *${formatDuration(res.resetIn)}*.`);
				}
				limitUsed = true;
			}

			await plugin(m, pluginData);
		} catch (err) {
			if (limitUsed) {
				try { pluginData.db.refundLimit(m.sender, 1); } catch {}
			}
			console.error(`[PLUGIN] Error '${commandText}':`, err);
			_notifyOwner(`plugins/${commandText}`, err);
			
			sock.sendMessage(m.chat, {
              text: `plugins error, detail error di kirim ke @${global.owner}`,
               contextInfo: {
                 mentionedJid: [global.owner + '@s.whatsapp.net']
               }
            }, { quoted: m })
		}
	}
};

export const getPluginStats = () => {
	const baseDir = path.join(process.cwd(), 'plugins');
	if (!fs.existsSync(baseDir)) return { totalCategory: 0, totalFiles: 0, data: [] };

	const folders = fs.readdirSync(baseDir).filter(f => fs.statSync(path.join(baseDir, f)).isDirectory());
	const result = [];
	let totalFiles = 0;

	for (const folder of folders) {
		const files = fs.readdirSync(path.join(baseDir, folder)).filter(f => f.match(/\.(js|mjs|cjs)$/));
		totalFiles += files.length;
		result.push({ category: folder, count: files.length });
	}

	result.sort((a, b) => a.category.localeCompare(b.category));
	return { totalCategory: folders.length, totalFiles, data: result };
};

export const getMenuData = ({ jadibot = false } = {}) => {
	const baseDir = path.join(process.cwd(), 'plugins');
	if (!fs.existsSync(baseDir)) return {};

	const result = {};

	for (const [filePath, cache] of _fileCache.entries()) {
		const folder = path.basename(path.dirname(filePath));
		const cmds = cache.plugin?.command;
		if (!Array.isArray(cmds) || !cmds.length) continue;
		if (jadibot && (cache.plugin.noJadiBot || cache.plugin.mainOwner)) continue;
		if (!result[folder]) result[folder] = [];
		result[folder].push({ cmd: cmds[0], aliases: cmds.slice(1) });
	}

	for (const folder of fs.readdirSync(baseDir)) {
		if (fs.statSync(path.join(baseDir, folder)).isDirectory() && !result[folder]) {
			result[folder] = [];
		}
	}

	return result;
};

export const handleGroupUpdate = async (update, sock) => {
	if (!_pluginCache) await loadPlugins();
	const db = sock?.db || global.mainDb;

	for (const plugin of _pluginCache) {
		if (typeof plugin.onGroupUpdate === 'function') {
			try {
				await plugin.onGroupUpdate(update, { sock, db, botSet: db.botSet, getGroup: db.getGroup, updateData: db.updateData });
			} catch (e) {
				console.error(`[GROUP_UPDATE] Error:`, e.message);
			}
		}
	}
};