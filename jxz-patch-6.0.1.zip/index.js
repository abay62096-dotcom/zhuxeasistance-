/*

  WhatsApp bot base || Zhuxee-Asistance 
  WhatsApp bot dengan library Baileys & runtime di NodeJs
  
  * Creator : Abay
  * Follow : https://whatsapp.com/channel/0029VbBoflt4dTnNWXV4zC09

 Jangan lupa baca README.md & EXAMPLE.js yaa

*/

process.on('uncaughtException', (err) => {
	console.error('Caught exception:', err);
});

import './lib/import.js';

import { makeWASocket, useMultiFileAuthState, fetchLatestBaileysVersion, DisconnectReason, downloadContentFromMessage, jidDecode, jidNormalizedUser, Browsers, delay, generateWAMessageFromContent, prepareWAMessageMedia, decryptPollVote } from '@whiskeysockets/baileys';

import fs from 'fs';
import crypto from 'crypto';
import chalk from 'chalk';
import { pathToFileURL } from 'url';
import pino from 'pino';
import { Boom } from '@hapi/boom';
import path from 'path';
import readline from 'readline';
import qrcode from 'qrcode-terminal';
import { fileTypeFromBuffer } from 'file-type';
import NodeCache from 'node-cache';
import os from 'os';
import nou from 'node-os-utils';
import speed from 'performance-now';

const timestamp = speed();
const latensi = speed() - timestamp;
const tio = nou.os.oos();
const tot = await nou.drive.info();

async function InputNumber(promptText) {
	const rl = readline.createInterface({
		input: process.stdin,
		output: process.stdout,
	});
	return new Promise((resolve) => {
		rl.question(promptText, (answer) => {
			rl.close();
			resolve(answer);
		});
	});
}

const store = makeInMemoryStore();

const groupCache = new NodeCache({
	stdTTL: 5 * 60,
	useClones: false,
});

// ** sistem database ** //
// setting (public/prefix/multiprefix/pconly/gconly/noPrefix) otomatis di-load dari mainDb di lib/import.js
await initDb();

const pairingCode = true;
async function startBot() {
	const { state, saveCreds } = await useMultiFileAuthState('Auth');
	const { version: v } = await fetchLatestBaileysVersion();
	
	const sock = makeWASocket({
		printQRInTerminal: !pairingCode,
		auth: state,
		version: v,
		browser: Browsers.macOS('Safari'),
		syncFullHistory: true,
		markOnlineOnConnect: true,

		cachedGroupMetadata: async (jid) => {
			return groupCache.get(jid);
		},

		getMessage: async (key) => {
        const crm = crmstore.loadMessage(key.id, key.remoteJid);
            if (crm) return crm;
        
            if (store) {
                const msg = store.loadMessage(key.remoteJid, key.id);
                return msg?.message || undefined;
            }
            return undefined;
        },
        
		logger: pino({ level: 'silent' }),
	});

	sock.db = mainDb;
	sock.botSet = mainDb.botSet;

	store.bind(sock.ev)
    global.store = store
    crmstore.bind(sock)
    
    makeButtonsHelper(sock)
    makeA2UIHelper(sock)
    makeRichHelper(sock)

	console.clear();
    
	if (pairingCode && !sock.authState.creds.registered) {
		let phoneNumber = await InputNumber(chalk.cyan.bold('[!] -  Enter your number, Example 628:\n'));
		phoneNumber = phoneNumber.replace(/[^0-9]/g, '');
		setTimeout(async () => {
			const code = await sock.requestPairingCode(phoneNumber);
			const pair = code.slice(0, 4) + '-' + code.slice(4, 8);
			console.clear();
			await console.log(`${chalk.white.bold('[✓] - Your code')} : ${chalk.green.bold(pair)}`);
		}, 5000);
	}

	sock.ev.on('creds.update', saveCreds);

	sock.ev.on('groups.update', async ([event]) => {
		try {
			const metadata = await sock.groupMetadata(event.id);
			groupCache.set(event.id, metadata);
		} catch {}
	});
	
    sock.ev.on('group-participants.update', async (event) => {
      try {
        const metadata = await sock.groupMetadata(event.id); 
        groupCache.set(event.id, metadata);
        await handleGroupUpdate(event, sock)
      } catch {}
    })

	sock.ev.on('connection.update', async ({ connection, lastDisconnect, qr }) => {
		if (!connection) return;
		if (connection === 'connecting') {
			if (qr && !pairingCode) {
				console.log('Scan QR ini di WhatsApp:');
				qrcode.generate(qr, { small: true });
			}
		}
		if (connection === 'close') {
			const reason = new Boom(lastDisconnect?.error)?.output?.statusCode;
			console.error(lastDisconnect.error);

			switch (reason) {
				case DisconnectReason.badSession:
					console.log('Bad Session File, Please Delete Session and Scan Again');
					process.exit();
				case DisconnectReason.connectionClosed:
					console.log('[SYSTEM] Connection closed, reconnecting...');
					await startBot();
					break;
				case DisconnectReason.connectionLost:
					console.log('[SYSTEM] Connection lost, trying to reconnect...');
					await startBot();
					break;
				case DisconnectReason.connectionReplaced:
					console.log('Connection Replaced, Another New Session Opened. Please Close Current Session First.');
					await sock.logout();
					break;
				case DisconnectReason.restartRequired:
					console.log('Restart Required...');
					await startBot();
					break;
				case DisconnectReason.loggedOut:
					console.log('Device Logged Out, Please Scan Again And Run.');
					await sock.logout();
					break;
				case DisconnectReason.timedOut:
					console.log('Connection TimedOut, Reconnecting...');
					await startBot();
					break;

				default:
					const errorMsg = lastDisconnect.error?.message;

					if (errorMsg === 'Error: Stream Errored (unknown)' || errorMsg === 'Stream Errored (unknown)') {
						console.log('[SYSTEM] Stream Errored (unknown) detected. Reconnecting...');
						await startBot();
					} else {
						console.error(`[SYSTEM] Disconnect Reason (Unhandled): ${reason} - ${lastDisconnect.error}`);
						await startBot();
					}
			}
		} else if (connection === 'open') {
			console.clear();
			sock.insertAllGroup();
			global.mainSock = sock;
			
			const loaded = await loadPlugins();
			console.log(
			  chalk.green.bold(' [ plugins ] - ') +
			  chalk.white.bold(`${loaded.length} file plugin berhasil dimuat`));
			  
			delay(1000);

			console.log(chalk.green.bold(`\n[ system ] - script ${global.namaBot} berhasil terkoneksi\n`));

			const botNumber = sock?.user?.id?.split(':')[0] || sock?.user?.jid?.replace('@s.whatsapp.net', '') || 'Unknown';
			const botName = sock?.user?.name || 'Unknown';

			console.log(
              chalk.white.bold(`\n[ system ] - `) +
              chalk.magenta.bold(`bot connected to:`) +
              chalk.white.bold(`
  ├ number : ${botNumber}
  └ name   : ${botName}`));

            console.log(
              chalk.white.bold(`\n[ bot ] - `) +
              chalk.magenta.bold(`source info:`) +
              chalk.white.bold(`
  ├ ${'bot name'.padEnd(13)} : ${global.namaBot} 
  ├ ${'version'.padEnd(13)} : ${global.versi}
  ├ ${'creator'.padEnd(13)} : ${global.namaOwner}
  ├ ${'type'.padEnd(13)} : ${global.typeSc}
  ├ ${'module'.padEnd(13)} : ${global.module}
  ├ ${'library'.padEnd(13)} : ${global.library}
  ├ ${'runtime'.padEnd(13)} : ${global.rtBot}
  └ ${'database'.padEnd(13)} : ${global.data}`));

            console.log(
              chalk.white.bold(`\n[ bot ] - `) +
              chalk.magenta.bold(`bot settings:`) +
              chalk.white.bold(`
  ├ ${'mode'.padEnd(10)} : ${global.public ? 'public mode' : 'self mode'}
  └ ${'prefix'.padEnd(10)} : ${global.multiprefix ? `${global.prefix || '.'}` : 'multi prefix'}`));

            console.log(
              chalk.white.bold(`\n[ system  ] - `) +
              chalk.magenta.bold(`server info:`) +
              chalk.white.bold(`
  ├ ${'runtime VPS'.padEnd(13)} : ${runtime(os.uptime())}
  ├ ${'platform'.padEnd(13)} : ${nou.os.type()}
  ├ ${'total RAM'.padEnd(13)} : ${formatp(os.totalmem())}
  ├ ${'total DISK'.padEnd(13)} : ${tot.totalGb} GB
  └ ${'total CPU'.padEnd(13)} : ${os.cpus().length} Core\n\n`));

			console.log(chalk.white.bold(`   Script telah terkoneksi ke WhatsApp anda,
   Hindari spam berlebih,
   Jangan biarkan bot digunakan di private chat,
   Ini bersifat ilegal/tidak resmi,
   semua resiko di tanggung pengguna!`));
			console.log(chalk.blue.bold(`\n   © Abay || Zhuxee-Asistance\n`));
			startWatcher();
		}
	});

	const pollCmdVoted = new Set() 
	const sha256hex = (str) => crypto.createHash('sha256').update(str, 'utf-8').digest('hex')

	const decryptVoteGeneric = async (voteMsg) => {
		const pu = voteMsg.message?.pollUpdateMessage
		if (!pu) return null

		const creationKey = pu.pollCreationMessageKey
		const pollMsgId = creationKey?.id
		if (!pollMsgId) return null

		const pollCreation = store.loadMessage(creationKey.remoteJid, pollMsgId)?.message
		if (!pollCreation) return null

		const pollEncKey = pollCreation?.messageContextInfo?.messageSecret
		if (!pollEncKey) return null

		const { encPayload, encIv } = pu.vote || {}
		if (!encPayload || !encIv) return null

		const meLid = sock.user?.lid ? jidNormalizedUser(sock.user.lid) : null
		const mePn = sock.user?.id ? jidNormalizedUser(sock.user.id) : null
		const creatorCandidates = [meLid, mePn].filter(Boolean)

		const rawVoter = voteMsg.key?.participant || voteMsg.key?.remoteJid
		const voterCandidates = new Set()
		if (rawVoter) {
			voterCandidates.add(rawVoter)
			voterCandidates.add(jidNormalizedUser(rawVoter))
		}
		if (voteMsg.key?.participantAlt) {
			voterCandidates.add(voteMsg.key.participantAlt)
			voterCandidates.add(jidNormalizedUser(voteMsg.key.participantAlt))
		}

		if (rawVoter?.endsWith('@lid') && !voteMsg.key?.participantAlt && creationKey.remoteJid?.endsWith('@g.us')) {
			try {
				const meta = await sock.getCachedGroupMetadata(creationKey.remoteJid).catch(() => null)
				const participant = meta?.participants?.find(p => p.id === rawVoter || p.lid === rawVoter)
				if (participant?.phoneNumber) voterCandidates.add(jidNormalizedUser(participant.phoneNumber))
				if (participant?.jid) voterCandidates.add(jidNormalizedUser(participant.jid))
			} catch {}
		}

		let decoded = null
		for (const pollCreatorJid of creatorCandidates) {
			for (const voterJid of voterCandidates) {
				try {
					decoded = decryptPollVote(
						{ encPayload, encIv },
						{ pollCreatorJid, pollMsgId, pollEncKey, voterJid }
					)
					if (decoded) break
				} catch { /* kombinasi salah, coba kombinasi lain */ }
			}
			if (decoded) break
		}

		if (!decoded) return null

		const selectedHashes = (decoded.selectedOptions || []).map(b => Buffer.from(b).toString('hex'))
		const voterJidFinal = jidNormalizedUser(voteMsg.key?.participantAlt || rawVoter)

		return { pollMsgId, creationKey, selectedHashes, voterJidFinal }
	}

	const handlePollVote = async (voteMsg) => {
		try {
			const result = await decryptVoteGeneric(voteMsg)
			if (!result) return
			const { pollMsgId, selectedHashes, voterJidFinal } = result

			const pollDb = getPollCommands()
			const entry = pollDb[pollMsgId]

			if (entry) {
				if (entry.expireAt && Date.now() > entry.expireAt) {
					delete pollDb[pollMsgId]
					saveDatabase()
					return
				}

				const hashToName = {}
				for (const optName of Object.keys(entry.options || {})) {
					hashToName[sha256hex(optName)] = optName
				}

				for (const hash of selectedHashes) {
					const optName = hashToName[hash]
					if (!optName) continue

					const cmdText = entry.options?.[optName]
					if (!cmdText) continue

					const dedupeKey = `${pollMsgId}:${voterJidFinal}:${optName}`
					if (pollCmdVoted.has(dedupeKey)) continue
					pollCmdVoted.add(dedupeKey)
					setTimeout(() => pollCmdVoted.delete(dedupeKey), 5 * 60 * 1000)

					const isGroupChat = entry.chat.endsWith('@g.us')
					const fakeKey = {
						remoteJid: isGroupChat ? entry.chat : voterJidFinal,
						participant: isGroupChat ? voterJidFinal : undefined,
						fromMe: false,
						id: 'POLLCMD' + Date.now() + Math.floor(Math.random() * 1000)
					}

					const fakeMsg = {
						key: fakeKey,
						message: { conversation: `${global.prefix || '.'}${cmdText}` },
						messageTimestamp: Math.floor(Date.now() / 1000),
						pushName: 'PollVoter'
					}

					try {
						const fm = await ConfigBaileys(sock, fakeMsg)
						await handler_cmd(sock, fm, { messages: [fakeMsg], type: 'notify' })
					} catch (e) {
						console.error('[POLLCMD] Gagal eksekusi command dari vote:', e)
					}
				}
				return
			}

			const vkDb = getVoteKicks()
			const vkEntry = vkDb[pollMsgId]
			if (!vkEntry) return
			if (vkEntry.kicked) return

			if (vkEntry.expireAt && Date.now() > vkEntry.expireAt) {
				delete vkDb[pollMsgId]
				saveDatabase()
				return
			}

			const kickHash = sha256hex('Kick')
			const votedKick = selectedHashes.includes(kickHash)
			if (!votedKick) return 

			const dedupeKey = `${pollMsgId}:${voterJidFinal}:kick`
			if (pollCmdVoted.has(dedupeKey)) return
			pollCmdVoted.add(dedupeKey)
			setTimeout(() => pollCmdVoted.delete(dedupeKey), 60 * 60 * 1000)

			vkEntry.voters = vkEntry.voters || []
			if (!vkEntry.voters.includes(voterJidFinal)) vkEntry.voters.push(voterJidFinal)

			const voteCount = vkEntry.voters.length

			if (voteCount >= vkEntry.threshold) {
				vkEntry.kicked = true
				vkDb[pollMsgId] = vkEntry
				saveDatabase()

				try {
					await sock.groupParticipantsUpdate(vkEntry.chat, [vkEntry.target], 'remove')
					await sock.sendMessage(vkEntry.chat, {
						text: `*Vote kick* berhasil @${vkEntry.target.split('@')[0]} dikeluarkan (${voteCount}/${vkEntry.threshold} vote "Kick").`,
						mentions: [vkEntry.target]
					})
				} catch (e) {
					console.error('[VOTEKICK] Gagal eksekusi kick:', e)
					await sock.sendMessage(vkEntry.chat, {
						text: `Threshold *vote kick* tercapai!
gagal mengeluarkan @${vkEntry.target.split('@')[0]} (pastikan bot admin!).`,
						mentions: [vkEntry.target]
					}).catch(() => {})
				}
			} else {
				vkDb[pollMsgId] = vkEntry
				saveDatabase()
			}
		} catch (e) {
			console.error('[POLLCMD] EXCEPTION saat proses vote:', e?.message)
			console.error(e?.stack)
		}
	}

	sock.ev.on('messages.upsert', async (chatUpdate) => {
		try {
			if (chatUpdate.type !== 'notify') return;
			const msg = chatUpdate.messages[0];
			if (!msg.message) return;

			if (msg.message.pollUpdateMessage) {
				await handlePollVote(msg)
				return
			}

            if (msg.key.fromMe && !global.bot) return;
			const m = await ConfigBaileys(sock, msg);
			
			await handler_cmd(sock, m, chatUpdate);
		} catch (err) {
			console.error('Error on message:', err);
		}
	});

	store.onDelete(async (key, cached) => {
		try {
			const jid = key.remoteJid
			if (!jid?.endsWith('@g.us')) return

			const chatDb = await getGroup(jid).catch(() => null)
			if (!chatDb || chatDb.antidelete !== 1) return
			if (!cached?.message) return

			let deleter = key.participant || cached.key?.participant || ''
			const meta = await sock.getCachedGroupMetadata(jid).catch(() => null)

			if (!deleter) return

			const foundParticipant = meta?.participants?.find(p => p.id === (key.participant || ''))
			const deleterName = cached.pushName || foundParticipant?.username || deleter.split('@')[0]

			const botJid = sock.decodeJid(sock.user.id)
			const norm = (j) => j?.split('@')[0]?.split(':')[0] || ''

			if (norm(deleter) === norm(botJid)) return

			const ownerNums = (global.owner || []).map(v => v.replace(/[^0-9]/g, ''))
			if (ownerNums.includes(norm(deleter))) return

			const admins = (meta?.participants || [])
				.filter(p => p.admin === 'admin' || p.admin === 'superadmin')
				.map(p => {
					if (p.phoneNumber) return norm(p.phoneNumber)
					if (p.username) return norm(p.username + '@s.whatsapp.net')
					return norm(p.id || '')
				})
			if (admins.includes(norm(deleter))) return

			const msg = cached.message
			let tipe = 'Tidak diketahui'
			if (msg.conversation || msg.extendedTextMessage) tipe = 'teks'
			else if (msg.imageMessage) tipe = 'image'
			else if (msg.videoMessage) tipe = 'video'
			else if (msg.audioMessage) tipe = msg.audioMessage.ptt ? 'voice note' : 'audio'
			else if (msg.stickerMessage) tipe = 'stiker'
			else if (msg.documentMessage) tipe = `document (${msg.documentMessage.fileName || 'file'})`

			const notif = `*Anti delete mesage!*\n\n> sender: *${deleterName}*\n> message type: *${tipe}*`

			if (msg.conversation || msg.extendedTextMessage) {
				const text = msg.conversation || msg.extendedTextMessage?.text || ''
				await sock.sendMessage(jid, {
					text: `${notif}\n\n*message delete:*\n${text}`,
					mentions: [deleter]
				})
			} else if (msg.imageMessage) {
				try {
					const stream = await downloadContentFromMessage(msg.imageMessage, 'image')
					let buf = Buffer.from([])
					for await (const chunk of stream) buf = Buffer.concat([buf, chunk])
					await sock.sendMessage(jid, {
						image: buf,
						caption: `${notif}${msg.imageMessage.caption ? '\n\n*caption:* ' + msg.imageMessage.caption : ''}`,
						mentions: [deleter]
					})
				} catch {
					await sock.sendMessage(jid, { text: `${notif}\n\n*foto tidak bisa direcovery*`, mentions: [deleter] })
				}
			} else if (msg.videoMessage) {
				try {
					const stream = await downloadContentFromMessage(msg.videoMessage, 'video')
					let buf = Buffer.from([])
					for await (const chunk of stream) buf = Buffer.concat([buf, chunk])
					await sock.sendMessage(jid, {
						video: buf,
						caption: `${notif}${msg.videoMessage.caption ? '\n\n*caption:* ' + msg.videoMessage.caption : ''}`,
						mentions: [deleter]
					})
				} catch {
					await sock.sendMessage(jid, { text: `${notif}\n\n*video tidak bisa direcovery*`, mentions: [deleter] })
				}
			} else if (msg.audioMessage) {
				try {
					const stream = await downloadContentFromMessage(msg.audioMessage, 'audio')
					let buf = Buffer.from([])
					for await (const chunk of stream) buf = Buffer.concat([buf, chunk])
					await sock.sendMessage(jid, {
						audio: buf,
						mimetype: msg.audioMessage.mimetype || 'audio/ogg; codecs=opus',
						ptt: msg.audioMessage.ptt || false
					})
					await sock.sendMessage(jid, { text: notif, mentions: [deleter] })
				} catch {
					await sock.sendMessage(jid, { text: `${notif}\n\n*audio tidak bisa direcovery*`, mentions: [deleter] })
				}
			} else if (msg.stickerMessage) {
				try {
					const stream = await downloadContentFromMessage(msg.stickerMessage, 'sticker')
					let buf = Buffer.from([])
					for await (const chunk of stream) buf = Buffer.concat([buf, chunk])
					await sock.sendMessage(jid, { sticker: buf })
					await sock.sendMessage(jid, { text: notif, mentions: [deleter] })
				} catch {
					await sock.sendMessage(jid, { text: `${notif}\n\n*stiker tidak bisa direcovery*`, mentions: [deleter] })
				}
			} else if (msg.documentMessage) {
				try {
					const stream = await downloadContentFromMessage(msg.documentMessage, 'document')
					let buf = Buffer.from([])
					for await (const chunk of stream) buf = Buffer.concat([buf, chunk])
					await sock.sendMessage(jid, {
						document: buf,
						mimetype: msg.documentMessage.mimetype || 'application/octet-stream',
						fileName: msg.documentMessage.fileName || 'file',
						caption: notif
					})
				} catch {
					await sock.sendMessage(jid, { text: `${notif}\n\n*dokumen tidak bisa direcovery*`, mentions: [deleter] })
				}
			} else {
				await sock.sendMessage(jid, { text: notif, mentions: [deleter] })
			}

		} catch (err) {
			console.error('[Anti-Delete] Error:', err)
		}
	})

	attachIdentityHelpers(sock, groupCache);

	sock.saveMessageToStore = (msg) => store.saveMessage(msg);

	sock.downloadAndSaveMediaMessage = async (message, filename, attachExtension = true) => {
		try {
			const quoted = message.msg ? message.msg : message;
			const mime = (message.msg || message).mimetype || '';
			const messageType = message.mtype ? message.mtype.replace(/Message/gi, '') : mime.split('/')[0];

			const Randoms = Date.now();
			const fil = Randoms;

			if (!fs.existsSync('./data/trash')) {
				fs.mkdirSync('./data/trash', { recursive: true });
			}

			const stream = await downloadContentFromMessage(quoted, messageType);
			let buffer = Buffer.from([]);

			for await (const chunk of stream) {
				buffer = Buffer.concat([buffer, chunk]);
			}

			const type = (await fileTypeFromBuffer(buffer)) || { ext: 'bin', mime: 'application/octet-stream' };
			const trueFileName = attachExtension ? `./data/trash/${fil}.${type.ext}` : filename || `./data/trash/${fil}.${type.ext}`;

			fs.writeFileSync(trueFileName, buffer);

			return trueFileName;
		} catch (err) {
			console.error('Error saat download media:', err);
			return null;
		}
	};

	sock.downloadM = async (m, type, filename = '') => {
		if (!m || !(m.url || m.directPath)) return Buffer.alloc(0);
		const stream = await downloadContentFromMessage(m, type);
		let buffer = Buffer.from([]);
		for await (const chunk of stream) {
			buffer = Buffer.concat([buffer, chunk]);
		}
		if (filename) await fs.promises.writeFile(filename, buffer);
		return filename && fs.existsSync(filename) ? filename : buffer;
	};

	sock.sendImageAsSticker = async (jid, path, quoted, options = {}) => {
		let buff = Buffer.isBuffer(path)
			? path
			: /^data:.*?\/.*?;base64,/i.test(path)
				? Buffer.from(path.split`, `[1], 'base64')
				: /^https?:\/\//.test(path)
					? await await getBuffer(path)
					: fs.existsSync(path)
						? fs.readFileSync(path)
						: Buffer.alloc(0);

		const type = (await fileTypeFromBuffer(buff)) || {};
		const isWebp = type.mime === 'image/webp';
		const isVideo = /^video\//.test(type.mime || '');

		let buffer;
		if (options && (options.packname || options.author)) {
			if (isWebp) {
				buffer = await writeExif({ mimetype: 'image/webp', data: buff }, options);
			} else if (isVideo) {
				buffer = await writeExifVid(buff, options);
			} else {
				buffer = await writeExifImg(buff, options);
			}
		} else {
			buffer = isWebp ? buff : isVideo ? await videoToWebp(buff) : await imageToWebp(buff);
		}

		await sock.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
		return buffer;
	};

	sock.sendVideoAsSticker = async (jid, path, quoted, options = {}) => {
		let buff = Buffer.isBuffer(path)
			? path
			: /^data:.*?\/.*?;base64,/i.test(path)
				? Buffer.from(path.split`, `[1], 'base64')
				: /^https?:\/\//.test(path)
					? await await getBuffer(path)
					: fs.existsSync(path)
						? fs.readFileSync(path)
						: Buffer.alloc(0);

		let buffer;
		if (options && (options.packname || options.author)) {
			buffer = await writeExifVid(buff, options);
		} else {
			buffer = await videoToWebp(buff);
		}

		await sock.sendMessage(jid, { sticker: { url: buffer }, ...options }, { quoted });
		return buffer;
	};

	sock.getFile = async (PATH, save) => {
		let res;
		let data = Buffer.isBuffer(PATH)
			? PATH
			: /^data:.*?\/.*?;base64,/i.test(PATH)
				? Buffer.from(PATH.split`,`[1], 'base64')
				: /^https?:\/\//.test(PATH)
					? await (res = await getBuffer(PATH))
					: fs.existsSync(PATH)
						? ((filename = PATH), fs.readFileSync(PATH))
						: typeof PATH === 'string'
							? PATH
							: Buffer.alloc(0);

		let type = (await fileTypeFromBuffer(data)) || {
			mime: 'application/octet-stream',
			ext: 'bin',
		};

		filename = path.join(__filename, './data/trash/' + new Date() * 1 + '.' + type.ext);
		if (data && save) fs.promises.writeFile(filename, data);
		return {
			res,
			filename,
			size: await getSizeMedia(data),
			...type,
			data,
		};
	};

	sock.sendFile = async (jid, path, filename = '', caption = '', quoted, ptt = false, options = {}) => {
		let type = await sock.getFile(path, true);
		let { res, data: file, filename: pathFile } = type;

		if ((res && res.status !== 200) || file.length <= 65536) {
			try {
				throw {
					json: JSON.parse(file.toString()),
				};
			} catch (e) {
				if (e.json) throw e.json;
			}
		}

		let opt = {
			filename,
		};

		if (quoted) opt.quoted = quoted;
		if (!type) options.asDocument = true;

		let mtype = '',
			mimetype = type.mime,
			convert;

		if (/webp/.test(type.mime) || (/image/.test(type.mime) && options.asSticker)) mtype = 'sticker';
		else if (/image/.test(type.mime) || (/webp/.test(type.mime) && options.asImage)) mtype = 'image';
		else if (/video/.test(type.mime)) mtype = 'video';
		else if (/audio/.test(type.mime)) {
			convert = await (ptt ? toPTT : toAudio)(file, type.ext);
			file = convert.data;
			pathFile = convert.filename;
			mtype = 'audio';
			mimetype = 'audio/ogg; codecs=opus';
		} else mtype = 'document';

		if (options.asDocument) mtype = 'document';

		delete options.asSticker;
		delete options.asLocation;
		delete options.asVideo;
		delete options.asDocument;
		delete options.asImage;

		let message = { ...options, caption, ptt, [mtype]: { url: pathFile }, mimetype };
		let m;

		try {
			m = await sock.sendMessage(jid, message, { ...opt, ...options });
		} catch (e) {
			//console.error(e)
			m = null;
		} finally {
			if (!m) m = await sock.sendMessage(jid, { ...message, [mtype]: file }, { ...opt, ...options });
			file = null;
			return m;
		}
	};

	sock.sendContact = async (jid, kon = [], name, desk = 'Developer Bot', quoted = '', opts = {}) => {
		const list = kon.map((i) => ({
			displayName: typeof name !== 'undefined' ? name : 'Unknown',
			vcard:
				'BEGIN:VCARD\n' +
				'VERSION:3.0\n' +
				`N:;${name || 'Unknown'};;;\n` +
				`FN:${name || 'Unknown'}\n` +
				'ORG:Unknown\n' +
				'TITLE:\n' +
				`item1.TEL;waid=${i}:${i}\n` +
				'item1.X-ABLabel:Ponsel\n' +
				`X-WA-BIZ-DESCRIPTION:${desk}\n` +
				`X-WA-BIZ-NAME:${name || 'Unknown'}\n` +
				'END:VCARD',
		}));

		await sock.sendMessage(jid, { contacts: { displayName: `${list.length} Kontak`, contacts: list }, ...opts }, { quoted });
	};
}

startBot();

fs.watchFile(__filename, () => {
	fs.unwatchFile(__filename);
	console.log(chalk.white.bold('~> Update File :'), chalk.green.bold(__filename));
	import(`${pathToFileURL(__filename).href}?update=${Date.now()}`);
});