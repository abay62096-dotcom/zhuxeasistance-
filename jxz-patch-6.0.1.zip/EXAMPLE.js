/*

  WhatsApp bot base || Zhuxee-Asistance 
  WhatsApp bot dengan library Baileys & runtime di NodeJs
  
  * Creator : Abay
  * Follow : https://whatsapp.com/channel/0029VbBoflt4dTnNWXV4zC09

 Jangan lupa baca README.md & EXAMPLE.js yaa

*/

// All type buttons
await sock.sendMessage(m.chat, {
  image: { url: "https://foto.jpg" },
  text: 'Hallo aku zhuxee',
  footer: '© Abay',
  buttons: [
    { 
      displayText: 'Reply', 
      id: 'balas' 
    },
    {
      displayText: 'Url', 
      url: 'https://t.me/xstoretelebot' 
    },
    { 
      displayText: 'Call', 
      call: '628xxxxx' 
    },
    { 
      displayText: 'Copy', 
      copy: 'KODE123' 
    },
    { 
      displayText: 'Reminder', 
      type: 'reminder' 
    },
    { 
      type: 'send_location' 
    },
    { 
      displayText: 'Alamat', 
      type: 'address' 
    },
    { 
      transaction_id: '26625178293769528' 
    },
    { 
      product_id: '26625178293769528' 
    },
    {
      catalog_product_id: '26625178293769528', 
      business_phone_number: '628xxxxx' 
    },
    {
      flow_id: '26625178293769528',
      flow_cta: 'galaxy',
      flow_action: 'navigate',
      icon: 'GALAXY',
      flow_action_payload: {
        screen: 'SATISFACTION_SCREEN',
        data: { title: 'zhuxee' }
      }
    },
    {
      title: 'DOC',
      sections: [{
        title: 'default',
        rows: [
          { title: 'ping', description: 'cek ping', id: 'ping' },
          { title: 'runtime', description: 'cek runtime', id: 'runtime' }
        ]
      }],
      icon: 'DEFAULT'
    },
    {
      title: 'PROMO',
      sections: [{
        title: 'Promotion',
        highlight_label: 'Promo',
        rows: [
          { header: 'PROMO', title: 'Lihat Promo', description: 'Show promotion', id: 'promo' }
        ]
      }],
      icon: 'PROMOTION'
    },
    {
      title: 'DEFAULT',
      sections: [{
        title: 'DEFAULT',
        rows: [
          { title: 'ping', description: 'cek ping', id: 'ping' },
          { title: 'menu', description: 'lihat menu', id: 'menu' }
        ]
      }],
      icon: 'NONE'
    }
  ]
}, { quoted: m })

// All type buttons + bottom sheet
await sock.sendButtons(m.chat, {
  text: 'Hallo aku zhuxee',
  footer: '© Abay',
  messageParams: {
    bottom_sheet: {
      in_thread_buttons_limit: 1,
      list_title: 'bottom_sheet',
      button_title: '© Abay'
    }
  },
  buttons: [
    { 
      displayText: 'Reply', 
      id: 'balas' 
    },
    {
      displayText: 'Url', 
      url: 'https://t.me/xstoretelebot' 
    },
    { 
      displayText: 'Call', 
      call: '628xxxxx' 
    },
    { 
      displayText: 'Copy', 
      copy: 'KODE123' 
    },
    { 
      displayText: 'Reminder', 
      type: 'reminder' 
    },
    { 
      type: 'send_location' 
    },
    { 
      displayText: 'Alamat', 
      type: 'address' 
    },
    { 
      transaction_id: '26625178293769528' 
    },
    { 
      product_id: '26625178293769528' 
    },
    {
      catalog_product_id: '26625178293769528', 
      business_phone_number: '628xxxxx' 
    },
    {
      flow_id: '26625178293769528',
      flow_cta: 'galaxy',
      flow_action: 'navigate',
      icon: 'GALAXY',
      flow_action_payload: {
        screen: 'SATISFACTION_SCREEN',
        data: { title: 'zhuxee' }
      }
    },
    {
      title: 'DOC',
      sections: [
        {
          title: 'default',
          rows: [
            { title: 'ping', description: 'cek ping', id: 'ping' },
            { title: 'runtime', description: 'cek runtime', id: 'runtime' }
          ]
        }
      ],
      icon: 'DEFAULT'
    },
    {
      title: 'PROMO',
      sections: [
        {
          title: 'Promotion',
          highlight_label: 'Promo',
          rows: [
            { header: 'PROMO', title: 'Lihat Promo', description: 'Show promotion', id: 'promo' }
          ]
        }
      ],
      icon: 'PROMOTION'
    },
    {
    title: 'DEFAULT',
    sections: [
        {
          title: 'DEFAULT',
          rows: [
            { title: 'ping', description: 'cek ping', id: 'ping' },
            { title: 'menu', description: 'lihat menu', id: 'menu' }
          ]
        }
      ],
    icon: "NONE"
   }
  ]
}, { quoted: m })

// All type buttons + document
await sock.sendMessage(m.chat, {
  document: { url: 'https://url.jpg' },
  mimetype: 'application/pdf',
  filename: 'zhuxee.pdf',
  text: 'Hallo aku zhuxee',
  footer: '© Abay',
  buttons: [
    { 
      displayText: 'Reply', 
      id: 'balas' 
    },
    {
      displayText: 'Url', 
      url: 'https://t.me/xstoretelebot' 
    },
    { 
      displayText: 'Call', 
      call: '628xxxxx' 
    },
    { 
      displayText: 'Copy', 
      copy: 'KODE123' 
    },
    { 
      displayText: 'Reminder', 
      type: 'reminder' 
    },
    { 
      type: 'send_location' 
    },
    { 
      displayText: 'Alamat', 
      type: 'address' 
    },
    { 
      transaction_id: '26625178293769528' 
    },
    { 
      product_id: '26625178293769528' 
    },
    {
      catalog_product_id: '26625178293769528', 
      business_phone_number: '628xxxxx' 
    },
    {
      flow_id: '26625178293769528',
      flow_cta: 'galaxy',
      flow_action: 'navigate',
      icon: 'GALAXY',
      flow_action_payload: {
        screen: 'SATISFACTION_SCREEN',
        data: { title: 'zhuxee' }
      }
    },
    {
      title: 'DOC',
      sections: [{
        title: 'default',
        rows: [
          { title: 'ping', description: 'cek ping', id: 'ping' },
          { title: 'runtime', description: 'cek runtime', id: 'runtime' }
        ]
      }],
      icon: 'DEFAULT'
    },
    {
      title: 'PROMO',
      sections: [{
        title: 'Promotion',
        highlight_label: 'Promo',
        rows: [{ header: 'PROMO', title: 'Lihat Promo', description: 'Show promotion', id: 'promo' }]
      }],
      icon: 'PROMOTION'
    },
    {
      title: 'DEFAULT',
      sections: [{
        title: 'DEFAULT',
        rows: [
          { title: 'ping', description: 'cek ping', id: 'ping' },
          { title: 'menu', description: 'lihat menu', id: 'menu' }
        ]
      }],
      icon: 'NONE'
    }
  ]
}, { quoted: m })

// Carousel + buttons
await sock.sendMessage(m.chat, {
  type: 'carousel',
  text: 'Produk Pilihan',
  cards: [
    {
      image: { url: 'https://example.com/img1.jpg' },
      body: 'image 1',
      footer: '© Abay',
      buttons: [
        { displayText: 'Beli', id: 'beli_a' },
        { displayText: 'Detail', url: 'https://example.com' }
      ]
    },
    {
      image: { url: 'https://example.com/img2.jpg' },
      body: 'image 2',
      footer: '© Abay',
      buttons: [
        { displayText: 'Beli', id: 'beli_b' },
        { displayText: 'Detail', url: 'https://example.com' }
      ]
    }
  ]
}, { quoted: m })

// Buttons location + image auto resize (via helper)
await sock.sendMessage(m.chat, {
  type: 'location_buttons',
  thumbnail: 'https://url.jpg',
  text: 'Zhuxee:',
  footer: '© Abay',
  lat: -0,
  lng: 0,
  buttons: [
    { displayText: 'Klik', id: 'ya' },
    { displayText: 'Klik', id: 'yo' }
  ]
}, { quoted: m })

// Buttons location, image + single select
await sock.sendMessage(m.chat, {
  type: 'location_buttons',
  thumbnail: 'https://url.jpg',
  text: 'Example:',
  footer: '© Abay',
  lat: -0,
  lng: 0,
  buttons: [
    {
      displayText: 'Zhuxee',
      id: 'menu',
      sections: [{
        title: 'Zhuxee Greyat',
        highlight_label: '',
        rows: [
          { 
            header: 'tes 1', 
            title: 'Example 1', 
            description: 'Contoh kode', 
            id: 'zhuxee' 
          },
          { 
            header: 'tes 2', 
            title: 'Example 1', 
            description: 'Contoh kode', 
            id: 'zhuxee' 
          }
        ]
      }]
    }
  ]
}, { quoted: m })

// Original Produk/catalog message 
await sock.sendProduct(m.chat, {
  image: { url: 'https://url.jpg' },
  productId: 'id_catalog',
  title: '© Abay',
  description: 'woi',
  text: 'teks', 
  price: 10000,
  currency: 'IDR',
  retailerId: 'p-001',
  url: 'https://example.com/kaos',
  businessJid: m.sender
}, { quoted: m })

// Produk/catalog message + buttons
await sock.sendProduct(m.chat, {
  image: { url: "https://url.jpg" },
  productId: 'id_catalog',
  title: 'Nama Produk',
  description: 'Deskripsi',
  text: 'Teks body',
  footer: '© Abay',
  price: 10000,
  currency: 'IDR',
  retailerId: '4144242',
  businessJid: m.sender,
  buttons: [
    {
      title: 'DEFAULT',
      sections: [{
        title: 'DEFAULT',
        rows: [
          { title: 'ping', description: 'cek ping', id: 'ping' },
          { title: 'menu', description: 'lihat menu', id: 'menu' }
        ]
      }],
      icon: 'NONE'
    }
  ]
}, { quoted: m })

//Produc mesages list
sock.sendProductList(m.chat, {
  title: "zhuxee",
  text: "Pilih produk",
  thumbnail: 'https://url.jpg',
  businessJid: "62xx@s.whatsapp.net",
  sections: [
    {
      title: "Promo",
      products: [
        { productId: "id_catalog" },
        { productId: "id_catalog" }
      ]
    },
    {
      title: "Promo",
      products: [
        { productId: "id_catalog" }
      ]
    }
  ],
  footer: "© Abay"
})

// Poll original 
await sock.sendPoll(m.chat, {
  title: 'Pilih salah satu:',
  options: ['Opsi A', 'Opsi B', 'Opsi C'],
  selectableCount: 1
}, { quoted: m })

// Poll snapshot (hasil poll)
await sock.sendPollSnapshot(m.chat, {
  name: 'Pilih salah satu:',  
  pollVotes: [
    { 
      optionName: 'Opsi A', 
      optionVoteCount: 5 
    },
    { 
      optionName: 'Opsi B', 
      optionVoteCount: 3 
    }
  ]
}, { quoted: m })

// Poll image 
await sock.sendImagePoll(m.chat, {
  title: 'Pilih',
  options: [
    { 
      name: 'Foto 1', 
      image: { url: 'https://foto.jpg' } 
    },
    { 
      name: 'Foto 2', 
      image: { url: 'https://foto.jpg' } 
    }
  ]
}, { quoted: m })

// polling command (trigger command menggunakan polling)
await sock.pollCmd(m.chat, {
  title: 'Pilih',
  options: [
    { 
      option: 'Ping', 
      command: `${usedPrefix}ping` 
    },
    { 
      option: 'Menu', 
      command: `${usedPrefix}menu` 
    },
    { 
      option: 'Runtime', 
      command: `${usedPrefix}runtime` 
    }
  ],
  selectableCount: 1,
  time: 60 * 60 * 1000
}, { quoted: m })

// Event message original 
await sock.sendEvent(m.chat, {
  name: 'Nama Event',
  startTime: '2026-06-10T09:00:00'
})

// Event message + booking button 
await sock.sendMessage(m.chat, {
  type: 'booking_confirmation',
  title: 'Zhuxee',
  text: 'Hello everyone!!',
  footer: '© Abay',
  start_datetime: '2026-05-27T13:35:41.081Z',
  end_datetime: '2026-05-27T13:45:41.081Z',
  location: 'Indonesia',
  booking_url: 'https://t.me/xstoretelebot',
  phone_number: '62xxx',
  booking_management_url: 'https://t.me/xstoretelebot',
  description: 'zhuxee its here',
  email: 'jarexe8@gmail.com',
  display_text: 'Contoh',
  display_content: {
    display_language: 'id',
    display_meeting_type: 'Example codes!'
  }
}, { quoted: m })

// Extended text mesage 
await sock.sendLinkPreview(m.chat, {
  text: 'https://github.com\nContohnya',
  url: 'https://github.com',
  title: 'Example code',
  description: '© Abay',
  thumbnail: "https://foto.jpg", 
  thumbnailWidth: 768,
  thumbnailHeight: 1280
}, { quoted: m })

// review_and_pay/pesanan
await sock.sendMessage(m.chat, {
  type: 'review_and_pay',
  image: { url: 'https://url.jpg' },
  title: 'Zhuxee-Asistance',
  text: 'Example codes',
  footer: '© Abay',
  paymentParams: {
    currency: 'IDR',
    total_amount: { value: 20000000, offset: 100 },
    reference_id: 'zhuxee',
    order_request_id: crypto.randomUUID(),
    type: 'digital-goods',
    order: {
      status: 'shipped',
      subtotal: { value: 20000000, offset: 100 },
      tax: { value: 8, offset: 100 },
      discount: { value: 6400, offset: 100 },
      shipping: { value: 4, offset: 100 },
      order_type: 'ORDER',
      items: [{
        retailer_id: '778739a4-e7b1-4295-9f29-ed3daec92a95',
        name: 'zhuxee',
        amount: { value: 900000, offset: 100 },
        quantity: 1
      }]
    },
    additional_note: 'zhuxee'
  }
}, { quoted: m })

// Rich mesage Text biasa
await sock.sendMessage(m.chat, {
  rich: {
    text: 'Halo! Ini pesan biasa.'
  }
}, { quoted: m })

// Rich mesage Text + hyperlink
await sock.sendMessage(m.chat, {
  rich: {
    text: 'Kunjungi [Link](https://t.me/xstoretelebot) untuk info lebih lanjut'
  }
}, { quoted: m })

// Rich mesage Text + citation
await sock.sendMessage(m.chat, {
  rich: {
    text: 'Hallo cari panel? klik: [](https://t.me/xstoretelebot)'
  }
}, { quoted: m })

// Rich mesage Code block
await sock.sendMessage(m.chat, {
  rich: {
    text: 'Contoh kode:',
    code: ['javascript', `let text = 'Hello im zhuxee'\nm.reply(text)`],
    footer: 'Abay'
  }
}, { quoted: m })

// Rich mesage Tabel
await sock.sendMessage(m.chat, {
  rich: {
    text: 'Daftar harga:',
    table: [
      ['Produk', 'Harga', 'Stok'],
      ['Apel',   '5000',  '100'],
      ['Jeruk',  '3000',  '200'],
      ['Mangga', '8000',  '50']
    ]
  }
}, { quoted: m })

// Rich mesage Gambar single
await sock.sendMessage(m.chat, {
  rich: {
    text: 'Ini gambarnya:',
    image: 'https://example.com/foto.jpg'
  }
}, { quoted: m })

// Rich mesage Gambar multiple
await sock.sendMessage(m.chat, {
  rich: {
    image: [
      'https://example.com/foto1.jpg',
      'https://example.com/foto2.jpg',
      'https://example.com/foto3.jpg'
    ]
  }
}, { quoted: m })

// Rich mesage Video
await sock.sendMessage(m.chat, {
  rich: {
    text: 'Ini videonya:',
    video: { url: 'https://example.com/video.mp4', duration: 30 }
  }
}, { quoted: m })

// Rich mesage Source / referensi
await sock.sendMessage(m.chat, {
  rich: {
    text: 'Berikut sumber informasinya:',
    source: [
      ['https://google.com/favicon.ico', 'https://google.com', 'Google'],
      ['https://wikipedia.org/favicon.ico', 'https://wikipedia.org', 'Wikipedia']
    ]
  }
}, { quoted: m })

// Rich mesage Product single
await sock.sendMessage(m.chat, {
  rich: {
    product: {
      title: 'zhuxee?',
      brand: '© Abay',
      price: 'Rp 1.200.000',
      sale_price: 'Rp 950.000',
      url: 'https://tokopedia.com',
      image: global.thumbnail,
      icon: 'https://example.com.jpg'
    },
    text: 'The result:'
  }
}, { quoted: m })

// Rich mesage Product multiple
await sock.sendMessage(m.chat, {
  rich: {
    text: 'Select:',
    product: [
      {
        title: 'Example 1',
        brand: '© Abay',
        price: 'Rp 1.200.000',
        sale_price: 'Rp 950.000',
        url: 'https://tokopedia.com',
        image: 'https://example.com.jpg'
      },
      {
        title: 'Example 2',
        brand: '© Abay',
        price: 'Rp 1.000.000',
        sale_price: 'Rp 800.000',
        url: 'https://tokopedia.com',
        image: 'https://example.com.jpg'
      }
    ]
  }
}, { quoted: m })

// Rich mesage Post sosmed
await sock.sendMessage(m.chat, {
  rich: {
    post: [{
      username: 'usr',
      profile_url: 'https://example.com/avatar.jpg',
      thumbnail: 'https://example.com/thumb.jpg',
      caption: 'caption postingan',
      url: 'https://instagram.com/p/xxx',
      like: 500,
      comment: 20,
      share: 10,
      source: 'INSTAGRAM',
      verified: true,
      post_type: 'VIDEO',
      orientation: 'LANDSCAPE'
    }]
  }
}, { quoted: m })

// Rich mesage Tips + suggest
await sock.sendMessage(m.chat, {
  rich: {
    text: 'Jawaban di atas berdasarkan data terbaru.',
    tip: '💡 Tip: Gunakan dengan bijak ya!',
    suggest: ['Cari resep', 'Cek cuaca', 'Buat kode']
  }
}, { quoted: m })

// Rich mesage product 
await sock.sendMessage(m.chat, {
  rich: {
    product: [{
      title: 'Example 1',
      brand: '© Abay',
      price: 'Rp 2.000.000',
      sale_price: 'Rp 1.500.000',
      url: 'https://tokopedia.com',
      image: 'https://example.com.jpg'
    }],
  }
}, { quoted: m })

// Rich mesage footerAction (menampilkan buttons mirip cta url)
await sock.sendMessage(m.chat, {
  rich: {
    footerAction: {
      text: 'Hubungi Owner',
      type: 'OPEN_URL',
      url: 'https://wa.me/6285700158613'
    }
  }
}, { quoted: m })

// Rich mesage reels
eval await sock.sendMessage(m.chat, {
  rich: {
    reels: {
      videoUrl: 'https://example.com/video.mp4',
      thumbnailUrl: 'https://example.com/thumbnail.jpg',
      profileIconUrl: 'https://example.com/avatar.jpg',

      username: 'Abay',
      title: 'Instagram Reels',
      reels_title: 'Reels terbaru',

      likes_count: 12500,
      shares_count: 350,
      view_count: 85000,

      reel_source: 'IG',
      is_verified: true
    }
  }
}, { quoted: m })

// A2UI Message Thubnail + buttons 
await sock.sendA2UI(m.chat, {
  text: 'Hallo aku zhuxee',
  image: 'https://example.com/foto.jpg',
  singleScreen: false,
  footer: '© Abay',
  buttons: [
    { displayText: 'Reply', id: 'balas' },
    { displayText: 'Url', url: 'https://t.me/xstoretelebot' }
  ]
}, { quoted: m })

// A2UI Message Thubnail 
await sock.sendA2UI(m.chat, {
  text: 'Hallo aku zhuxee',
  image: 'https://example.com/foto.jpg',
  singleScreen: false,
}, { quoted: m })