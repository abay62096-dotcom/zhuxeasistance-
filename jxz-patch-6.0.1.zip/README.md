# Zhuxee-Asistance v6.0.1

# INFO 📢
  * Creator: Abay
  * Contact: t.me/abay
  * Follow: https://whatsapp.com/channel/0029Vb9I0xb9sBI6cISS243f
  * Bot name: Zhuxee-Asistance
  * Version: 6.0.1
  * Library: Original baileys
  * Type: plugins
  * Modules: ECMAScript Module (ESM)
  * Runtime: NodeJS

# FEATURES 🤖
  * Support buttons, Carousel, Produc, Catalog, richAi, a2ui, dll
  * Auto detected kalo user belum punya username ambil lid, jika user belum punya username ambil jid
  * Auto reload plugin, auto add cmd baru ke menu, auto add folder category baru
  * Handler limit, owner, premium, dll
  * Jadibot (database terpisah dari bot utama)
  * Terdapat beberapa fitur bawaan
  * No bad sesions
  * Free dokumentasi penggunaan helper
  * Tanpa newsletter follow
  * dll

# PENGGUNAAN 👤
  * User wajib ubah nomor owner di file settings.js > cari global.owner = ["62xx"]
  * Ubah juga di file ./data/owner.json ["62xxx@s.whatsapp.net","62xxx@s.whatsapp.net"]
  * Note, format wajib sama seperti di atas agar tidak eror
  * Jika nomor bukan dari Indonesia tulis saja full format nya tanpa spasi, strip (-), kurung buka (), & tambah (+)
  * Contoh +1 (548) 457-xxxx, maka cara penulisan nya adalah 1548457xxxx

# HANDLER PLUGINS 📂
    handler.owner = true //only owners
    handler.premium = true //harus premium
    handler.group = true //harus di dalam grup
    handler.private = true //harus di private chat
    handler.admin = true //yang pake harus admin
    handler.botadmin = true //bot harus admin
    handler.noJadiBot = true //agar fitur tidak bisa dipake saat ada yang jadibot (biasanya di taruh di fitur owner)
    handler.mainOwner = true //filter handler khusus, agar Fitur2 berbahaya seperti eval, backup, dll tidak bisa di pake oleh User jadibot
    handler.limit = true //handler limit taruh di fitur plugin yang ingin menggunakan fitur limit (default limit 10 setting di settings.js)

    true = aktif
    false = nonaktif

# CONTOH KODE PLUGINS 📂
const handler = async (m, { sock }) => {
   m.reply("contoh!!")
}
handler.command = ["tes"]
handler.owner = true
handler.noJadiBot = true
handler.group = false

export default handler;

# RUNNING 🖥️

** PANEL PETERODACTYL **
1. masuk ke panel kalian
2. masuk ke file
3. upload script
4. pencet ( ⋮ ) titik tiga di sebelah kanan file yang telah di upload
5. pilih unzip
6. terus masuk ke console > klik start > tunggu sampai di suruh masuk in nomor > masuk in nomor 62xxx enter > tautin ke wa > done!!

** VPS (VIRTUAL PRIVATE SERVER) **
1. siapin vps nya login vps nya di apk termius
2. masuk terus setting dulu vps nya (kalo belum di setting)
    apt update &&  apt install wget && wget https://raw.githubusercontent.com/nvm-sh/nvm/master/install.sh && bash install.sh && source ~/.bashrc && nvm install v22 && npm i pm2 -g && pm2 install ffmpeg && apt install git &&  apt install ffmpeg -y &&   apt install webp -y &&  apt install ffmpeg -y &&  apt install imagemagick -y && apt install unzip && apt install zip && apt install neofetch && apt-get install g++ && npm i gyp -g && apt-get install make && apt install python3-pip && apt install speedtest-cli && neofetch
   salin aja kode di atas tempel di vps kalian terus tunggu sampai selesai, kalo udah
3. pencet tanda ( + ) tanda tambah di atas > pilih SFTP
4. kalo udah pilih ( ⋮ ) titik tiga, kanan atas samping tulisan upload
5. pilih New Folder > namain folder nya, bebas untuk namanya
6. masuk ke folder yang udah di buat tadi > upload file script nya > pastikan nama script nya sama nama folder nya ingat yah
7. masuk ke terminal, ketik
    › cd nama folder yang udah di buat tadi
    › unzip nama-sc-yang-udah-di-upload.zip
    › npm install
    › node index.js (bagian index.js sesuaikan sama SC kalian)
    › tunggu info suruh masuk in nomor > masuk in nomor 62xxx > tautkan ke WhatsApp > balik ke apk termius lagi
    › pencet Ctrl + c
    › pm2 start index.js --name (bagian index.js sesuaikan sama SC kalian, bagian name itu buat nama bebas apa aja)
    › pm2 save > done script terpasang

# TIPS 📖
Jika bot anda ingin di public gunakan fitur tersebut, untuk menghindari bot di pake di private chat

.ongc ** (ketik dalam grup) **
.offgc ** (ketik dalam grup) **
.listgc

Mode bot anda tetap **mode self**
Jika salah satu grup dalam mode **ongc** maka walaupun mode self semua member tetap bisa menggunakan bot, (hanya di grup tersebut saja)
Ini jauh lebih aman daripada fitur pconly & gconly yang sudah di hapus.

Untuk memudahkan owner .noprfx on/off
jika **noprfx** dalam mode on maksa owner bisa menggunakan bot tanpa prefix di awal, tapi untuk user non owner tetep harus menggunakan prefix

# WARNING/ PERINGATAN ⚠️
  * Dilarang membagikan script secara gratis
  * Silahkan kembangkan, creator, credits sama contributor jangan di hapus 🙏

** Cara menggunakan Helper wraper untuk mengirim buttons, rich mesage, a2ui silahkan cek file EXAMPLE.js **

** Bila infomasi yang di berikan dalam README.md ini kurang jelas, langsung tanyakan kepada owner. **

** _Copyright (©) Abay 2026_ **
** _All rights reserved_ **

** 🇮🇩 Jangan hapus creator/credit maupun contributor **
** 🇬🇧 Do not delete creator/credit or contributor **

#whatsApp-bot #baileys #wabot #zhuxee-asistance #readme.md